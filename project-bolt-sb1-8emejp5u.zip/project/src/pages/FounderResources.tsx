import React from 'react';
import { motion } from 'framer-motion';
import Layout from '../components/layout/Layout';
import { Rocket, BookOpen, Users, Lightbulb, Download, FileCheck } from 'lucide-react';

export default function FounderResources() {
  React.useEffect(() => {
    document.title = 'Founder Resources | Dream Intake';
  }, []);

  return (
    <Layout>
      <div className="pt-20 pb-20 bg-primary-50 min-h-screen">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center mb-12"
          >
            <h1 className="text-4xl sm:text-5xl font-serif font-bold text-primary-900 mb-4">
              Founder <span className="text-gold-500">Resources</span>
            </h1>
            <p className="text-xl text-primary-600 max-w-3xl mx-auto">
              Essential tools and guides to help you build and grow your startup
            </p>
          </motion.div>

          <div className="max-w-4xl mx-auto space-y-8">
            {/* Pitch Deck Guide */}
            <motion.section
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="bg-white rounded-lg shadow-md p-8"
            >
              <div className="flex items-center mb-6">
                <Rocket className="w-8 h-8 text-gold-500 mr-3" />
                <h2 className="text-2xl font-bold text-primary-900">Pitch Deck Guide</h2>
              </div>
              <div className="space-y-4">
                <p className="text-primary-600">
                  A compelling pitch deck is crucial for attracting investors. Here's what to include:
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-primary-50 p-4 rounded-lg">
                    <h3 className="font-semibold text-primary-900 mb-2">Essential Slides</h3>
                    <ul className="space-y-2 text-primary-600">
                      <li>• Problem & Solution</li>
                      <li>• Market Opportunity</li>
                      <li>• Business Model</li>
                      <li>• Traction & Metrics</li>
                      <li>• Team & Experience</li>
                      <li>• Financial Projections</li>
                      <li>• Funding Ask</li>
                    </ul>
                  </div>
                  <div className="bg-primary-50 p-4 rounded-lg">
                    <h3 className="font-semibold text-primary-900 mb-2">Best Practices</h3>
                    <ul className="space-y-2 text-primary-600">
                      <li>• Keep it concise (10-15 slides)</li>
                      <li>• Use visuals effectively</li>
                      <li>• Tell a compelling story</li>
                      <li>• Include clear call-to-action</li>
                      <li>• Highlight unique value</li>
                    </ul>
                  </div>
                </div>
                <div className="mt-4">
                  <a href="#" className="inline-flex items-center text-gold-500 hover:text-gold-600">
                    <Download size={16} className="mr-2" />
                    Download Pitch Deck Template
                  </a>
                </div>
              </div>
            </motion.section>

            {/* Financial Planning */}
            <motion.section
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="bg-white rounded-lg shadow-md p-8"
            >
              <div className="flex items-center mb-6">
                <BookOpen className="w-8 h-8 text-gold-500 mr-3" />
                <h2 className="text-2xl font-bold text-primary-900">Financial Planning</h2>
              </div>
              <div className="space-y-4">
                <p className="text-primary-600">
                  Proper financial planning is essential for startup success and fundraising:
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-primary-50 p-4 rounded-lg">
                    <h3 className="font-semibold text-primary-900 mb-2">Key Financial Documents</h3>
                    <ul className="space-y-2 text-primary-600">
                      <li>• Financial Model</li>
                      <li>• Cash Flow Projections</li>
                      <li>• Income Statement</li>
                      <li>• Balance Sheet</li>
                      <li>• Cap Table</li>
                    </ul>
                  </div>
                  <div className="bg-primary-50 p-4 rounded-lg">
                    <h3 className="font-semibold text-primary-900 mb-2">Funding Requirements</h3>
                    <ul className="space-y-2 text-primary-600">
                      <li>• Detailed Cost Breakdown</li>
                      <li>• Growth Projections</li>
                      <li>• Runway Calculations</li>
                      <li>• Use of Funds</li>
                    </ul>
                  </div>
                </div>
                <div className="mt-4">
                  <a href="#" className="inline-flex items-center text-gold-500 hover:text-gold-600">
                    <Download size={16} className="mr-2" />
                    Download Financial Model Template
                  </a>
                </div>
              </div>
            </motion.section>

            {/* Legal Requirements */}
            <motion.section
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="bg-white rounded-lg shadow-md p-8"
            >
              <div className="flex items-center mb-6">
                <FileCheck className="w-8 h-8 text-gold-500 mr-3" />
                <h2 className="text-2xl font-bold text-primary-900">Legal Requirements</h2>
              </div>
              <div className="space-y-4">
                <p className="text-primary-600">
                  Essential legal documents and compliance requirements for your startup:
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-primary-50 p-4 rounded-lg">
                    <h3 className="font-semibold text-primary-900 mb-2">Required Documents</h3>
                    <ul className="space-y-2 text-primary-600">
                      <li>• Company Registration</li>
                      <li>• Founder Agreements</li>
                      <li>• IP Rights</li>
                      <li>• Employment Contracts</li>
                      <li>• Terms of Service</li>
                    </ul>
                  </div>
                  <div className="bg-primary-50 p-4 rounded-lg">
                    <h3 className="font-semibold text-primary-900 mb-2">Compliance Checklist</h3>
                    <ul className="space-y-2 text-primary-600">
                      <li>• Business Licenses</li>
                      <li>• Tax Registrations</li>
                      <li>• Industry Regulations</li>
                      <li>• Data Protection</li>
                    </ul>
                  </div>
                </div>
              </div>
            </motion.section>

            {/* Growth Strategies */}
            <motion.section
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
              className="bg-white rounded-lg shadow-md p-8"
            >
              <div className="flex items-center mb-6">
                <Lightbulb className="w-8 h-8 text-gold-500 mr-3" />
                <h2 className="text-2xl font-bold text-primary-900">Growth Strategies</h2>
              </div>
              <div className="space-y-4">
                <p className="text-primary-600">
                  Effective strategies to grow your startup and attract investors:
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-primary-50 p-4 rounded-lg">
                    <h3 className="font-semibold text-primary-900 mb-2">Marketing & Sales</h3>
                    <ul className="space-y-2 text-primary-600">
                      <li>• Digital Marketing</li>
                      <li>• Content Strategy</li>
                      <li>• Sales Funnel</li>
                      <li>• Customer Acquisition</li>
                      <li>• Brand Building</li>
                    </ul>
                  </div>
                  <div className="bg-primary-50 p-4 rounded-lg">
                    <h3 className="font-semibold text-primary-900 mb-2">Product Development</h3>
                    <ul className="space-y-2 text-primary-600">
                      <li>• MVP Strategy</li>
                      <li>• User Feedback</li>
                      <li>• Feature Prioritization</li>
                      <li>• Scaling Infrastructure</li>
                    </ul>
                  </div>
                </div>
              </div>
            </motion.section>

            {/* Mentorship & Support */}
            <motion.section
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.5 }}
              className="bg-white rounded-lg shadow-md p-8"
            >
              <div className="flex items-center mb-6">
                <Users className="w-8 h-8 text-gold-500 mr-3" />
                <h2 className="text-2xl font-bold text-primary-900">Mentorship & Support</h2>
              </div>
              <div className="space-y-4">
                <p className="text-primary-600">
                  Access mentorship and support resources to help you succeed:
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-primary-50 p-4 rounded-lg">
                    <h3 className="font-semibold text-primary-900 mb-2">Available Resources</h3>
                    <ul className="space-y-2 text-primary-600">
                      <li>• Expert Mentors</li>
                      <li>• Startup Workshops</li>
                      <li>• Networking Events</li>
                      <li>• Industry Connections</li>
                    </ul>
                  </div>
                  <div className="bg-primary-50 p-4 rounded-lg">
                    <h3 className="font-semibold text-primary-900 mb-2">Support Services</h3>
                    <ul className="space-y-2 text-primary-600">
                      <li>• Business Planning</li>
                      <li>• Technical Guidance</li>
                      <li>• Market Research</li>
                      <li>• Pitch Practice</li>
                    </ul>
                  </div>
                </div>
              </div>
            </motion.section>
          </div>
        </div>
      </div>
    </Layout>
  );
}