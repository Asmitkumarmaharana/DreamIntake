import React, { useEffect, useState } from 'react';
import Layout from '../components/layout/Layout';
import FilterBar from '../components/discover/FilterBar';
import StartupCard from '../components/discover/StartupCard';
import { useStartupStore } from '../store/startupStore';
import { Startup } from '../types';
import { motion } from 'framer-motion';

export default function Discover() {
  const { fetchStartups, filteredStartups, isLoading } = useStartupStore();
  const [selectedStartup, setSelectedStartup] = useState<Startup | null>(null);
  
  useEffect(() => {
    document.title = 'Discover Startups | Dream Intake';
    fetchStartups();
  }, [fetchStartups]);
  
  const handleStartupClick = (startup: Startup) => {
    setSelectedStartup(startup);
    document.body.style.overflow = 'hidden';
  };
  
  const closeModal = () => {
    setSelectedStartup(null);
    document.body.style.overflow = 'auto';
  };
  
  // Handle boosted startups
  const boostedStartups = filteredStartups.filter(s => s.isBoosted);
  const regularStartups = filteredStartups.filter(s => !s.isBoosted);
  
  return (
    <Layout>
      <div className="pt-20 pb-20 bg-primary-50 min-h-screen">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-8">
            <h1 className="text-3xl sm:text-4xl font-bold text-primary-900 mb-2">Discover Startups</h1>
            <p className="text-xl text-primary-600">
              Browse through innovative startups looking for funding and mentorship
            </p>
          </div>
          
          <FilterBar />
          
          {isLoading ? (
            <div className="flex justify-center py-20">
              <div className="animate-spin h-12 w-12 border-4 border-gold-500 rounded-full border-t-transparent"></div>
            </div>
          ) : (
            <>
              {/* Boosted startups section */}
              {boostedStartups.length > 0 && (
                <div className="mb-12">
                  <div className="flex items-center mb-6">
                    <h2 className="text-2xl font-bold text-primary-900 mr-3">Trending Now</h2>
                    <span className="bg-gold-500 text-white text-xs px-2 py-1 rounded-full">
                      HOT
                    </span>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {boostedStartups.map((startup, index) => (
                      <motion.div
                        key={startup.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.3, delay: index * 0.1 }}
                      >
                        <StartupCard 
                          startup={startup} 
                          onClick={() => handleStartupClick(startup)}
                        />
                      </motion.div>
                    ))}
                  </div>
                </div>
              )}
              
              {/* Regular startups section */}
              <div>
                <h2 className="text-2xl font-bold text-primary-900 mb-6">All Startups</h2>
                
                {regularStartups.length === 0 ? (
                  <div className="bg-white rounded-lg shadow-md p-8 text-center">
                    <p className="text-primary-600 mb-4">
                      No startups match your current filters. Try adjusting your search criteria.
                    </p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {regularStartups.map((startup, index) => (
                      <motion.div
                        key={startup.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.3, delay: index * 0.1 }}
                      >
                        <StartupCard 
                          startup={startup} 
                          onClick={() => handleStartupClick(startup)}
                        />
                      </motion.div>
                    ))}
                  </div>
                )}
              </div>
            </>
          )}
        </div>
      </div>
      
      {/* Startup detail modal */}
      {selectedStartup && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4"
          onClick={closeModal}
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-xl shadow-xl max-w-3xl w-full max-h-[90vh] overflow-y-auto"
            onClick={e => e.stopPropagation()}
          >
            {selectedStartup.pitchVideoUrl && (
              <div className="aspect-video bg-primary-900 relative">
                <div className="flex items-center justify-center h-full">
                  <p className="text-white">Video would be embedded here</p>
                </div>
              </div>
            )}
            
            <div className="p-6 sm:p-8">
              <div className="flex items-start justify-between mb-6">
                <div>
                  <h2 className="text-2xl sm:text-3xl font-bold text-primary-900 mb-2">
                    {selectedStartup.startupName}
                  </h2>
                  <div className="flex items-center">
                    <div className="h-8 w-8 rounded-full bg-primary-200 flex items-center justify-center text-primary-800 font-medium mr-2">
                      {selectedStartup.startupName.charAt(0)}
                    </div>
                    <span className="text-sm text-primary-500">{selectedStartup.location}</span>
                  </div>
                </div>
                
                <button 
                  onClick={closeModal}
                  className="text-primary-500 hover:text-primary-700"
                >
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path>
                  </svg>
                </button>
              </div>
              
              <div className="flex flex-wrap gap-2 mb-6">
                {selectedStartup.industries.map((industry, index) => (
                  <span 
                    key={index} 
                    className="text-sm bg-primary-100 text-primary-700 px-3 py-1 rounded-full"
                  >
                    {industry}
                  </span>
                ))}
              </div>
              
              <div className="mb-8">
                <h3 className="text-xl font-semibold text-primary-900 mb-3">About the Startup</h3>
                <p className="text-primary-700 whitespace-pre-line">
                  {selectedStartup.shortPitch}
                </p>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-4">
                <button className="flex-1 bg-gold-500 text-white py-3 px-6 rounded-lg font-medium hover:bg-gold-600 transition-colors">
                  Contact Founder
                </button>
                <button className="flex-1 border border-primary-300 text-primary-800 py-3 px-6 rounded-lg font-medium hover:bg-primary-50 transition-colors">
                  Express Interest
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </Layout>
  );
}