import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import Layout from '../components/layout/Layout';
import Button from '../components/ui/Button';
import Input from '../components/ui/Input';
import PitchStartupModal from '../components/profile/PitchStartupModal';
import { useAuthStore } from '../store/authStore';
import { Camera, MapPin, Building2, Users, Mail, Phone, Globe, Briefcase, Calendar, Edit2, Wallet, MessageSquare, Heart, TrendingUp, Key, LogOut, Lightbulb } from 'lucide-react';

export default function Profile() {
  const navigate = useNavigate();
  const { user, isAuthenticated, logout } = useAuthStore();
  const [isPitchModalOpen, setIsPitchModalOpen] = useState(false);

  React.useEffect(() => {
    if (!isAuthenticated) {
      navigate('/login');
      return;
    }
    document.title = 'Profile | Dream Intake';
  }, [isAuthenticated, navigate]);

  const [isEditing, setIsEditing] = useState(false);
  const [isChangingPassword, setIsChangingPassword] = useState(false);
  const [profileData, setProfileData] = useState({
    name: user?.name || '',
    email: user?.email || '',
    phone: '+91 98765 43210',
    website: 'https://ecoharvest.com',
    linkedin: 'https://linkedin.com/in/arjunpatel',
    instagram: 'https://instagram.com/arjunpatel',
    twitter: 'https://twitter.com/arjunpatel',
    bio: 'Serial entrepreneur with 10+ years of experience in AgriTech. Previously founded and successfully exited two startups in the sustainable agriculture space. Currently building EcoHarvest to revolutionize farming with IoT and AI.',
  });

  const [passwordData, setPasswordData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
  });

  const stats = {
    messagesExchanged: 156,
    startupsConnected: 12,
    totalBoosts: 3,
  };

  const paymentHistory = [
    {
      id: 1,
      type: 'Startup Pitch',
      amount: 1,
      date: '2024-02-15',
      status: 'Paid',
    },
    {
      id: 2,
      type: 'Trending Boost',
      amount: 300,
      date: '2024-02-10',
      status: 'Paid',
    },
    {
      id: 3,
      type: 'Trending Boost',
      amount: 300,
      date: '2024-01-25',
      status: 'Paid',
    },
  ];

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Handle image upload
      console.log('Uploading image:', file);
    }
  };

  const handlePasswordChange = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle password change
    console.log('Changing password:', passwordData);
    setIsChangingPassword(false);
  };

  const handleSave = () => {
    setIsEditing(false);
    // Save profile data
    console.log('Saving profile:', profileData);
  };

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const handlePitchSubmit = (data: any) => {
    console.log('New pitch submitted:', data);
    // Handle pitch submission logic here
  };

  return (
    <Layout>
      <div className="pt-20 pb-20 bg-primary-50 min-h-screen">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-5xl mx-auto">
            {/* Profile Header */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="bg-white rounded-xl shadow-md overflow-hidden mb-8"
            >
              <div className="h-48 bg-gradient-to-r from-primary-900 to-primary-800 relative">
                <Button
                  variant="ghost"
                  className="absolute top-4 right-4 text-white"
                  onClick={() => setIsEditing(!isEditing)}
                >
                  <Edit2 size={18} className="mr-2" />
                  {isEditing ? 'Cancel' : 'Edit Profile'}
                </Button>
              </div>
              
              <div className="px-8 pb-8">
                <div className="flex flex-col sm:flex-row items-start sm:items-end -mt-16 mb-6">
                  <div className="relative">
                    <div className="w-32 h-32 rounded-xl bg-white shadow-lg overflow-hidden">
                      <img
                        src="https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg"
                        alt={profileData.name}
                        className="w-full h-full object-cover"
                      />
                      {isEditing && (
                        <label className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-50 cursor-pointer group">
                          <Camera className="w-8 h-8 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
                          <input
                            type="file"
                            accept="image/*"
                            className="hidden"
                            onChange={handleImageUpload}
                          />
                        </label>
                      )}
                    </div>
                  </div>
                  
                  <div className="mt-6 sm:mt-0 sm:ml-6 flex-grow">
                    {isEditing ? (
                      <div className="space-y-4">
                        <Input
                          label="Name"
                          value={profileData.name}
                          onChange={(e) => setProfileData({ ...profileData, name: e.target.value })}
                          fullWidth
                        />
                        <Input
                          label="Email"
                          value={profileData.email}
                          onChange={(e) => setProfileData({ ...profileData, email: e.target.value })}
                          fullWidth
                        />
                      </div>
                    ) : (
                      <>
                        <h1 className="text-3xl font-bold text-primary-900">{profileData.name}</h1>
                        <p className="text-xl text-primary-600 capitalize">{user?.userType}</p>
                      </>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div className="flex items-center text-primary-600">
                      <Mail size={18} className="mr-2" />
                      {isEditing ? (
                        <Input
                          value={profileData.email}
                          onChange={(e) => setProfileData({ ...profileData, email: e.target.value })}
                          fullWidth
                        />
                      ) : (
                        <a href={`mailto:${profileData.email}`} className="hover:text-gold-500">
                          {profileData.email}
                        </a>
                      )}
                    </div>
                    <div className="flex items-center text-primary-600">
                      <Phone size={18} className="mr-2" />
                      {isEditing ? (
                        <Input
                          value={profileData.phone}
                          onChange={(e) => setProfileData({ ...profileData, phone: e.target.value })}
                          fullWidth
                        />
                      ) : (
                        <a href={`tel:${profileData.phone}`} className="hover:text-gold-500">
                          {profileData.phone}
                        </a>
                      )}
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <div className="flex items-center text-primary-600">
                      <Globe size={18} className="mr-2" />
                      {isEditing ? (
                        <Input
                          value={profileData.website}
                          onChange={(e) => setProfileData({ ...profileData, website: e.target.value })}
                          fullWidth
                        />
                      ) : (
                        <a href={profileData.website} target="_blank" rel="noopener noreferrer" className="hover:text-gold-500">
                          {profileData.website}
                        </a>
                      )}
                    </div>
                    <div className="flex items-center text-primary-600">
                      <svg className="w-[18px] h-[18px] mr-2" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M19 3a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14m-.5 15.5v-5.3a3.26 3.26 0 0 0-3.26-3.26c-.85 0-1.84.52-2.32 1.3v-1.11h-2.79v8.37h2.79v-4.93c0-.77.62-1.4 1.39-1.4a1.4 1.4 0 0 1 1.4 1.4v4.93h2.79M6.88 8.56a1.68 1.68 0 0 0 1.68-1.68c0-.93-.75-1.69-1.68-1.69a1.69 1.69 0 0 0-1.69 1.69c0 .93.76 1.68 1.69 1.68m1.39 9.94v-8.37H5.5v8.37h2.77z" />
                      </svg>
                      {isEditing ? (
                        <Input
                          value={profileData.linkedin}
                          onChange={(e) => setProfileData({ ...profileData, linkedin: e.target.value })}
                          fullWidth
                        />
                      ) : (
                        <a href={profileData.linkedin} target="_blank" rel="noopener noreferrer" className="hover:text-gold-500">
                          LinkedIn Profile
                        </a>
                      )}
                    </div>
                    <div className="flex items-center text-primary-600">
                      <svg className="w-[18px] h-[18px] mr-2" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M7.8 2h8.4C19.4 2 22 4.6 22 7.8v8.4a5.8 5.8 0 0 1-5.8 5.8H7.8C4.6 22 2 19.4 2 16.2V7.8A5.8 5.8 0 0 1 7.8 2m-.2 2A3.6 3.6 0 0 0 4 7.6v8.8C4 18.39 5.61 20 7.6 20h8.8a3.6 3.6 0 0 0 3.6-3.6V7.6C20 5.61 18.39 4 16.4 4H7.6m9.65 1.5a1.25 1.25 0 0 1 1.25 1.25A1.25 1.25 0 0 1 17.25 8 1.25 1.25 0 0 1 16 6.75a1.25 1.25 0 0 1 1.25-1.25M12 7a5 5 0 0 1 5 5 5 5 0 0 1-5 5 5 5 0 0 1-5-5 5 5 0 0 1 5-5m0 2a3 3 0 0 0-3 3 3 3 0 0 0 3 3 3 3 0 0 0 3-3 3 3 0 0 0-3-3z"/>
                      </svg>
                      {isEditing ? (
                        <Input
                          value={profileData.instagram}
                          onChange={(e) => setProfileData({ ...profileData, instagram: e.target.value })}
                          fullWidth
                        />
                      ) : (
                        <a href={profileData.instagram} target="_blank" rel="noopener noreferrer" className="hover:text-gold-500">
                          Instagram Profile
                        </a>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Pitch Another Startup Button (Only for founders) */}
            {user?.userType === 'founder' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.1 }}
                className="mb-8"
              >
                <Button
                  onClick={() => setIsPitchModalOpen(true)}
                  className="w-full sm:w-auto bg-gold-500 text-white hover:bg-gold-400"
                >
                  <Lightbulb size={18} className="mr-2" />
                  Pitch Another Startup Idea
                </Button>
              </motion.div>
            )}

            {/* Stats Section */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8"
            >
              <div className="bg-white rounded-xl p-6 shadow-md">
                <div className="flex items-center mb-2">
                  <MessageSquare className="w-5 h-5 text-gold-500 mr-2" />
                  <h3 className="font-semibold text-primary-900">Messages</h3>
                </div>
                <p className="text-2xl font-bold text-primary-900">{stats.messagesExchanged}</p>
                <p className="text-primary-600">Total exchanges</p>
              </div>

              <div className="bg-white rounded-xl p-6 shadow-md">
                <div className="flex items-center mb-2">
                  <Heart className="w-5 h-5 text-gold-500 mr-2" />
                  <h3 className="font-semibold text-primary-900">Connections</h3>
                </div>
                <p className="text-2xl font-bold text-primary-900">{stats.startupsConnected}</p>
                <p className="text-primary-600">Startups connected</p>
              </div>

              <div className="bg-white rounded-xl p-6 shadow-md">
                <div className="flex items-center mb-2">
                  <TrendingUp className="w-5 h-5 text-gold-500 mr-2" />
                  <h3 className="font-semibold text-primary-900">Boosts</h3>
                </div>
                <p className="text-2xl font-bold text-primary-900">{stats.totalBoosts}</p>
                <p className="text-primary-600">Total boosts used</p>
              </div>
            </motion.div>

            {/* Payment History */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="bg-white rounded-xl shadow-md p-6 mb-8"
            >
              <div className="flex items-center mb-6">
                <Wallet className="w-6 h-6 text-gold-500 mr-2" />
                <h2 className="text-xl font-bold text-primary-900">Payment History</h2>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-primary-100">
                      <th className="text-left py-3 px-4 text-primary-600 font-medium">Type</th>
                      <th className="text-left py-3 px-4 text-primary-600 font-medium">Amount</th>
                      <th className="text-left py-3 px-4 text-primary-600 font-medium">Date</th>
                      <th className="text-left py-3 px-4 text-primary-600 font-medium">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {paymentHistory.map((payment) => (
                      <tr key={payment.id} className="border-b border-primary-50">
                        <td className="py-3 px-4 text-primary-900">{payment.type}</td>
                        <td className="py-3 px-4 text-primary-900">₹{payment.amount}</td>
                        <td className="py-3 px-4 text-primary-600">
                          {new Date(payment.date).toLocaleDateString()}
                        </td>
                        <td className="py-3 px-4">
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-success-50 text-success-600">
                            {payment.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </motion.div>

            {/* Account Settings */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="bg-white rounded-xl shadow-md p-6 mb-8"
            >
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center">
                  <Key className="w-6 h-6 text-gold-500 mr-2" />
                  <h2 className="text-xl font-bold text-primary-900">Account Settings</h2>
                </div>
                <Button
                  variant="outline"
                  onClick={() => setIsChangingPassword(!isChangingPassword)}
                >
                  Change Password
                </Button>
              </div>

              {isChangingPassword && (
                <form onSubmit={handlePasswordChange} className="space-y-4">
                  <Input
                    type="password"
                    label="Current Password"
                    value={passwordData.currentPassword}
                    onChange={(e) => setPasswordData({ ...passwordData, currentPassword: e.target.value })}
                    required
                    fullWidth
                  />
                  <Input
                    type="password"
                    label="New Password"
                    value={passwordData.newPassword}
                    onChange={(e) => setPasswordData({ ...passwordData, newPassword: e.target.value })}
                    required
                    fullWidth
                  />
                  <Input
                    type="password"
                    label="Confirm New Password"
                    value={passwordData.confirmPassword}
                    onChange={(e) => setPasswordData({ ...passwordData, confirmPassword: e.target.value })}
                    required
                    fullWidth
                  />
                  <div className="flex justify-end space-x-4">
                    <Button
                      variant="outline"
                      onClick={() => setIsChangingPassword(false)}
                    >
                      Cancel
                    </Button>
                    <Button type="submit">
                      Update Password
                    </Button>
                  </div>
                </form>
              )}

              <div className="mt-8 pt-6 border-t border-primary-100">
                <Button
                  variant="outline"
                  className="text-error-600 border-error-600 hover:bg-error-50"
                  onClick={handleLogout}
                >
                  <LogOut size={18} className="mr-2" />
                  Logout
                </Button>
              </div>
            </motion.div>

            {/* Pitch Startup Modal */}
            <PitchStartupModal
              isOpen={isPitchModalOpen}
              onClose={() => setIsPitchModalOpen(false)}
              onSubmit={handlePitchSubmit}
            />
          </div>
        </div>
      </div>
    </Layout>
  );
}