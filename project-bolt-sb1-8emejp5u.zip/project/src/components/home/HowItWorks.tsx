import React from 'react';
import { motion } from 'framer-motion';
import { UserPlus, Rocket, ArrowRight, Zap } from 'lucide-react';

export default function HowItWorks() {
  const steps = [
    {
      icon: <UserPlus size={32} className="text-gold-500" />,
      title: "Sign Up",
      description: "Create your account as a founder or investor with our simple onboarding process.",
      color: "bg-blue-50"
    },
    {
      icon: <Rocket size={32} className="text-gold-500" />,
      title: "Create or Discover",
      description: "Submit your startup pitch or browse through existing startup ideas.",
      color: "bg-green-50"
    },
    {
      icon: <Zap size={32} className="text-gold-500" />,
      title: "Connect",
      description: "Reach out to potential investors or founders through our in-app messaging system.",
      color: "bg-purple-50"
    },
    {
      icon: <ArrowRight size={32} className="text-gold-500" />,
      title: "Fund & Grow",
      description: "Finalize investment details offline and take your startup to the next level.",
      color: "bg-orange-50"
    }
  ];
  
  return (
    <section className="py-20">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-3xl sm:text-4xl font-bold text-primary-900 mb-4"
          >
            How It Works
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-xl text-primary-600 max-w-3xl mx-auto"
          >
            Dream Intake makes the startup funding process simple and transparent
          </motion.p>
        </div>
        
        <div className="relative">
          {/* Connecting line */}
          <div className="absolute top-24 left-0 right-0 h-0.5 bg-gold-200 hidden md:block"></div>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {steps.map((step, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="flex flex-col items-center text-center relative"
              >
                <div className="w-16 h-16 rounded-full bg-white border-2 border-gold-300 flex items-center justify-center mb-6 z-10">
                  <span className="text-2xl font-bold text-gold-500">{index + 1}</span>
                </div>
                <div className={`p-6 rounded-lg ${step.color}`}>
                  <div className="mb-4">{step.icon}</div>
                  <h3 className="text-xl font-semibold text-primary-900 mb-2">{step.title}</h3>
                  <p className="text-primary-600">{step.description}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}