import React from 'react';
import { motion } from 'framer-motion';
import Card from '../ui/Card';
import { Trophy, Rocket, MessageSquare, TrendingUp, LineChart, Globe } from 'lucide-react';

export default function Features() {
  const features = [
    {
      icon: <Rocket size={32} className="text-gold-500" />,
      title: "Startup Discovery",
      description: "Browse through a curated selection of promising startups looking for funding and mentorship."
    },
    {
      icon: <Trophy size={32} className="text-gold-500" />,
      title: "Leaderboard Rankings",
      description: "See which startups are gaining the most traction and investor interest in real-time."
    },
    {
      icon: <MessageSquare size={32} className="text-gold-500" />,
      title: "Direct Communication",
      description: "Connect directly with founders or investors through our integrated messaging system."
    },
    {
      icon: <TrendingUp size={32} className="text-gold-500" />,
      title: "Boost Visibility",
      description: "Get featured in our trending section to maximize exposure to potential investors."
    },
    {
      icon: <LineChart size={32} className="text-gold-500" />,
      title: "Performance Metrics",
      description: "Track startup performance with detailed analytics and investor engagement metrics."
    },
    {
      icon: <Globe size={32} className="text-gold-500" />,
      title: "Pan-India Network",
      description: "Connect with founders and investors from across India, regardless of location."
    }
  ];
  
  return (
    <section className="py-20 bg-primary-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-3xl sm:text-4xl font-bold text-primary-900 mb-4"
          >
            Platform Features
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-xl text-primary-600 max-w-3xl mx-auto"
          >
            Everything you need to connect, fund, and grow in the startup ecosystem
          </motion.p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <Card floating padded>
                <div className="p-4 bg-primary-50 rounded-full inline-block mb-4">
                  {feature.icon}
                </div>
                <h3 className="text-xl font-semibold text-primary-900 mb-2">{feature.title}</h3>
                <p className="text-primary-600">{feature.description}</p>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}