import React from 'react';
import { motion } from 'framer-motion';
import Layout from '../components/layout/Layout';
import { ChevronDown } from 'lucide-react';

export default function FAQ() {
  const [openIndex, setOpenIndex] = React.useState<number | null>(null);

  const faqs = [
    {
      question: "How does Dream Intake work?",
      answer: "Dream Intake connects startup founders with potential investors. Founders can create detailed profiles, upload pitch videos, and showcase their startups. Investors can browse, filter, and connect with startups that match their investment criteria."
    },
    {
      question: "What are the registration fees?",
      answer: "Founders pay a one-time fee of ₹1 to register, while investors pay ₹99. These nominal fees help maintain platform quality and ensure serious participation."
    },
    {
      question: "How can I boost my startup's visibility?",
      answer: "You can boost your startup's visibility by paying ₹300, which places your startup in the trending section for 7 days, significantly increasing exposure to potential investors."
    },
    {
      question: "Is my information secure?",
      answer: "Yes, we take data security seriously. All sensitive information is encrypted, and we have strict privacy policies in place to protect both founders and investors."
    },
    {
      question: "How do I connect with investors/founders?",
      answer: "Once registered, you can use our built-in messaging system to communicate directly with investors or founders. Premium members get priority in message responses."
    },
    {
      question: "What happens after I find a potential match?",
      answer: "When there's mutual interest, you can schedule meetings, share detailed documents, and proceed with investment discussions through our platform or offline."
    },
    {
      question: "Can I update my startup profile?",
      answer: "Yes, you can update your startup profile, pitch video, and other details anytime through your dashboard to keep information current."
    },
    {
      question: "What types of startups can join?",
      answer: "We welcome startups from all sectors, but they must be registered businesses in India and have a clear business model and growth strategy."
    }
  ];

  return (
    <Layout>
      <div className="pt-20 pb-20 bg-primary-50 min-h-screen">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center mb-12"
          >
            <h1 className="text-4xl sm:text-5xl font-serif font-bold text-primary-900 mb-4">
              Frequently Asked <span className="text-gold-500">Questions</span>
            </h1>
            <p className="text-xl text-primary-600 max-w-3xl mx-auto">
              Find answers to common questions about Dream Intake
            </p>
          </motion.div>

          <div className="max-w-3xl mx-auto">
            {faqs.map((faq, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
                className="mb-4"
              >
                <button
                  onClick={() => setOpenIndex(openIndex === index ? null : index)}
                  className="w-full text-left bg-white rounded-lg shadow-sm px-6 py-4 focus:outline-none focus:ring-2 focus:ring-gold-500"
                >
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-medium text-primary-900">
                      {faq.question}
                    </h3>
                    <ChevronDown
                      size={20}
                      className={`text-primary-500 transition-transform ${
                        openIndex === index ? 'transform rotate-180' : ''
                      }`}
                    />
                  </div>
                  {openIndex === index && (
                    <motion.p
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="mt-4 text-primary-600"
                    >
                      {faq.answer}
                    </motion.p>
                  )}
                </button>
              </motion.div>
            ))}
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.5 }}
            className="mt-12 text-center"
          >
            <p className="text-primary-600">
              Still have questions?{' '}
              <a href="mailto:support@dreamintake.app" className="text-gold-500 hover:text-gold-600 font-medium">
                Contact our support team
              </a>
            </p>
          </motion.div>
        </div>
      </div>
    </Layout>
  );
}