import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import Button from '../ui/Button';
import Input from '../ui/Input';
import QRCodeDisplay from '../ui/QRCodeDisplay';
import { useAuthStore } from '../../store/authStore';

export default function FounderForm() {
  const navigate = useNavigate();
  const { signupFounder, isLoading, error } = useAuthStore();
  
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    startupName: '',
    startupIdea: '',
    pitchVideo: null as File | null,
  });
  
  const [hasCompleted, setHasCompleted] = useState(false);
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0] || null;
    setFormData(prev => ({ ...prev, pitchVideo: file }));
  };
  
  const handlePaymentComplete = () => {
    setHasCompleted(true);
    setTimeout(() => {
      setStep(2);
    }, 1500);
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      await signupFounder(
        formData.name,
        formData.email,
        formData.startupName,
        formData.startupIdea
      );
      
      navigate('/discover');
    } catch (error) {
      console.error('Signup failed:', error);
    }
  };
  
  return (
    <div className="w-full max-w-md mx-auto">
      {step === 1 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.3 }}
        >
          <h2 className="text-2xl font-bold text-primary-900 mb-2">Complete Payment</h2>
          <p className="text-primary-600 mb-6">
            Pay a small fee of ₹1 to get started as a founder on Dream Intake.
          </p>
          
          <QRCodeDisplay 
            amount={1} 
            description="One-time founder registration fee"
          />
          
          <div className="mt-8 flex justify-between">
            <Button variant="outline" onClick={() => navigate('/signup')}>
              Back
            </Button>
            
            <Button onClick={handlePaymentComplete} disabled={hasCompleted}>
              {hasCompleted ? 'Payment Verified ✓' : 'I have paid'}
            </Button>
          </div>
        </motion.div>
      )}
      
      {step === 2 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.3 }}
        >
          <h2 className="text-2xl font-bold text-primary-900 mb-2">Founder Details</h2>
          <p className="text-primary-600 mb-6">
            Tell us more about you and your startup idea.
          </p>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            <Input
              label="Full Name"
              type="text"
              name="name"
              value={formData.name}
              onChange={handleChange}
              placeholder="Your full name"
              required
              fullWidth
            />
            
            <Input
              label="Email Address"
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              placeholder="you@example.com"
              required
              fullWidth
            />
            
            <Input
              label="Password"
              type="password"
              name="password"
              value={formData.password}
              onChange={handleChange}
              placeholder="Choose a strong password"
              required
              fullWidth
            />
            
            <Input
              label="Startup Name"
              type="text"
              name="startupName"
              value={formData.startupName}
              onChange={handleChange}
              placeholder="Your startup name"
              required
              fullWidth
            />
            
            <div>
              <label className="block text-sm font-medium text-primary-700 mb-1">
                Startup Idea (Brief Summary)
              </label>
              <textarea
                name="startupIdea"
                value={formData.startupIdea}
                onChange={handleChange}
                placeholder="Describe your startup idea in a few sentences"
                rows={4}
                className="block w-full rounded-lg border border-primary-300 px-4 py-2.5 text-primary-900 placeholder-primary-400 focus:outline-none focus:ring-2 focus:ring-gold-500 focus:ring-opacity-50 focus:border-transparent"
                required
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-primary-700 mb-1">
                Pitch Video (1-2 minutes)
              </label>
              <div className="border border-dashed border-primary-300 rounded-lg p-4 text-center">
                <input
                  type="file"
                  name="pitchVideo"
                  accept="video/*"
                  onChange={handleFileChange}
                  className="hidden"
                  id="pitch-video"
                />
                <label 
                  htmlFor="pitch-video" 
                  className="cursor-pointer text-primary-600 hover:text-primary-800"
                >
                  {formData.pitchVideo
                    ? `Selected: ${formData.pitchVideo.name}`
                    : 'Upload your pitch video'}
                </label>
                <p className="text-xs text-primary-500 mt-1">
                  MP4, MOV or WebM format, max 50MB
                </p>
              </div>
            </div>
            
            {error && (
              <p className="text-error-500 text-sm">{error}</p>
            )}
            
            <div className="flex justify-between mt-8">
              <Button variant="outline" onClick={() => setStep(1)}>
                Back
              </Button>
              
              <Button type="submit" isLoading={isLoading}>
                Complete Registration
              </Button>
            </div>
          </form>
        </motion.div>
      )}
    </div>
  );
}