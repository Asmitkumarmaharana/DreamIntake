import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import Button from '../ui/Button';
import { ArrowRight } from 'lucide-react';

export default function CTASection() {
  return (
    <section className="py-20">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="bg-gradient-to-r from-primary-900 to-primary-800 rounded-3xl overflow-hidden"
        >
          <div className="relative p-8 sm:p-12 lg:p-16">
            {/* Background elements */}
            <div className="absolute top-0 right-0 -mt-20 -mr-20 w-64 h-64 rounded-full bg-gold-500 opacity-10"></div>
            <div className="absolute bottom-0 left-0 -mb-12 -ml-12 w-48 h-48 rounded-full bg-gold-500 opacity-10"></div>
            
            <div className="relative z-10 flex flex-col md:flex-row md:items-center md:justify-between">
              <div className="mb-8 md:mb-0 md:mr-8">
                <h2 className="text-3xl sm:text-4xl font-serif font-bold text-white mb-4">
                  Ready to Turn Your Dream Into Reality?
                </h2>
                <p className="text-xl text-primary-200 max-w-2xl">
                  Join Dream Intake today and connect with the right people to bring your vision to life.
                </p>
              </div>
              
              <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
                <Link to="/signup/founder">
                  <Button 
                    size="lg" 
                    className="bg-gold-500 text-white hover:bg-gold-400 shadow-lg"
                  >
                    Join as Founder
                    <ArrowRight size={18} className="ml-2" />
                  </Button>
                </Link>
                <Link to="/signup/investor">
                  <Button 
                    variant="outline" 
                    size="lg" 
                    className="border-2 border-white text-white hover:bg-white/10"
                  >
                    Join as Investor
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}