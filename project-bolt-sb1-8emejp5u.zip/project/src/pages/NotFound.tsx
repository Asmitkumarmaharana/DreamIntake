import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import Layout from '../components/layout/Layout';
import Button from '../components/ui/Button';
import { Home, ArrowLeft } from 'lucide-react';

export default function NotFound() {
  React.useEffect(() => {
    document.title = 'Page Not Found | Dream Intake';
  }, []);

  return (
    <Layout>
      <div className="pt-20 pb-20 bg-primary-50 min-h-screen">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-lg mx-auto text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <h1 className="text-9xl font-bold text-primary-900 mb-4">404</h1>
              <h2 className="text-2xl font-bold text-primary-800 mb-4">Page Not Found</h2>
              <p className="text-primary-600 mb-8">
                The page you're looking for doesn't exist or has been moved.
              </p>
              
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <Link to="/">
                  <Button>
                    <Home size={18} className="mr-2" />
                    Back to Home
                  </Button>
                </Link>
                <button 
                  onClick={() => window.history.back()}
                  className="flex items-center text-primary-600 hover:text-primary-800"
                >
                  <ArrowLeft size={18} className="mr-1" />
                  Go Back
                </button>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </Layout>
  );
}