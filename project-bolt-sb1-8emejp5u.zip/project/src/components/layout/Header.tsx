import React, { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Bell, Menu, X, User, LogOut } from 'lucide-react';
import Button from '../ui/Button';
import { useAuthStore } from '../../store/authStore';
import { motion, AnimatePresence } from 'framer-motion';

export default function Header() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const { user, isAuthenticated, logout } = useAuthStore();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setIsMenuOpen(false);
  }, [location]);

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'Discover', path: '/discover' },
    { name: 'Trending', path: '/trending' },
    { name: 'Leaderboard', path: '/leaderboard' },
  ];

  return (
    <header 
      className={`
        fixed top-0 left-0 right-0 z-50 transition-all duration-300
        ${isScrolled 
          ? 'bg-white shadow-md py-2' 
          : 'bg-transparent py-4 backdrop-blur-sm bg-white/50'}
      `}
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <nav className="flex items-center justify-between">
          <Link to="/" className="flex items-center">
            <div className="flex flex-col">
              <h1 className="text-2xl font-serif font-bold text-primary-900">
                Dream Intake
              </h1>
              <p className="text-xs text-gold-500 font-medium">
                Where Dreams Get Funded
              </p>
            </div>
          </Link>

          <div className="hidden md:flex items-center justify-center space-x-8">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`
                  text-base font-medium transition-all relative
                  ${location.pathname === link.path 
                    ? 'text-gold-500' 
                    : 'text-primary-800 hover:text-gold-500'}
                  group
                `}
              >
                {link.name}
                <span className={`
                  absolute -bottom-1 left-0 w-0 h-0.5 bg-gold-500 transition-all duration-300
                  group-hover:w-full
                  ${location.pathname === link.path ? 'w-full' : ''}
                `}></span>
              </Link>
            ))}
          </div>

          <div className="hidden md:flex items-center space-x-4">
            {isAuthenticated ? (
              <div className="flex items-center space-x-4">
                <button className="text-primary-800 hover:text-gold-500 transition-colors">
                  <Bell size={20} />
                </button>
                <div className="relative">
                  <button 
                    onClick={() => setIsProfileOpen(!isProfileOpen)}
                    className="flex items-center space-x-2"
                  >
                    <div className="h-9 w-9 rounded-full bg-gold-500 flex items-center justify-center text-white font-medium">
                      {user?.name.charAt(0)}
                    </div>
                  </button>

                  <AnimatePresence>
                    {isProfileOpen && (
                      <motion.div
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: 10 }}
                        className="absolute right-0 top-12 bg-white rounded-lg shadow-lg py-2 w-48 border border-primary-100"
                      >
                        <div className="px-4 py-2 border-b border-primary-100">
                          <p className="font-medium text-primary-900">{user?.name}</p>
                          <p className="text-sm text-primary-500 capitalize">{user?.userType}</p>
                        </div>
                        <Link 
                          to="/profile" 
                          className="flex items-center px-4 py-2 text-primary-600 hover:bg-primary-50"
                        >
                          <User size={16} className="mr-2" />
                          Profile
                        </Link>
                        <button 
                          onClick={handleLogout}
                          className="flex items-center w-full text-left px-4 py-2 text-primary-600 hover:bg-primary-50"
                        >
                          <LogOut size={16} className="mr-2" />
                          Logout
                        </button>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </div>
            ) : (
              <>
                <Link to="/login">
                  <Button variant="outline" size="sm">Log In</Button>
                </Link>
                <Link to="/signup">
                  <Button 
                    size="sm"
                    className="bg-gold-500 text-white hover:bg-gold-400"
                  >
                    Sign Up
                  </Button>
                </Link>
              </>
            )}
          </div>

          <button 
            className="md:hidden text-primary-800"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </nav>

        <AnimatePresence>
          {isMenuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="md:hidden bg-white border-t border-primary-100 mt-2"
            >
              <div className="py-4 space-y-2">
                {navLinks.map((link) => (
                  <Link
                    key={link.path}
                    to={link.path}
                    className={`
                      block py-2 px-4 text-base font-medium rounded-lg
                      ${location.pathname === link.path 
                        ? 'bg-gold-50 text-gold-500' 
                        : 'text-primary-800 hover:bg-primary-50'}
                    `}
                  >
                    {link.name}
                  </Link>
                ))}

                {isAuthenticated ? (
                  <>
                    <Link
                      to="/profile"
                      className="block py-2 px-4 text-base font-medium text-primary-800 hover:bg-primary-50"
                    >
                      Profile
                    </Link>
                    <button
                      onClick={handleLogout}
                      className="block w-full text-left py-2 px-4 text-base font-medium text-primary-800 hover:bg-primary-50"
                    >
                      Logout
                    </button>
                  </>
                ) : (
                  <div className="pt-4 space-y-2 px-4">
                    <Link to="/login" className="block">
                      <Button variant="outline" fullWidth>Log In</Button>
                    </Link>
                    <Link to="/signup" className="block">
                      <Button 
                        fullWidth
                        className="bg-gold-500 text-white hover:bg-gold-400"
                      >
                        Sign Up
                      </Button>
                    </Link>
                  </div>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </header>
  );
}