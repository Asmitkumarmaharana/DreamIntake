import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import Button from '../ui/Button';
import { ArrowRight } from 'lucide-react';
import CountUp from 'react-countup';

export default function Hero() {
  return (
    <section className="relative min-h-screen bg-gradient-to-b from-primary-900 to-primary-800 overflow-hidden">
      <div className="absolute inset-0 z-0">
        <motion.div 
          className="absolute top-1/4 -right-20 w-96 h-96 rounded-full bg-gold-500/5"
          animate={{ 
            scale: [1, 1.2, 1],
            opacity: [0.3, 0.2, 0.3],
          }}
          transition={{ 
            repeat: Infinity,
            duration: 8,
            ease: "easeInOut" 
          }}
        />
        <motion.div 
          className="absolute -bottom-32 -left-32 w-[40rem] h-[40rem] rounded-full bg-gold-400/5"
          animate={{ 
            scale: [1, 1.1, 1],
            opacity: [0.2, 0.1, 0.2],
          }}
          transition={{ 
            repeat: Infinity,
            duration: 10,
            ease: "easeInOut" 
          }}
        />
      </div>
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10 flex items-center justify-center min-h-screen">
        <div className="text-center max-w-4xl mx-auto pt-20 lg:pt-0">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-5xl sm:text-6xl lg:text-7xl font-serif font-bold text-white leading-tight mb-6">
              Where <span className="text-gold-400">Dreams</span> Get Funded
            </h1>
            <p className="text-xl text-primary-200 mb-8 max-w-2xl mx-auto">
              Connect with investors who believe in your vision. Dream Intake is where visionary founders meet forward-thinking investors to bring revolutionary ideas to life.
            </p>
            
            <div className="flex flex-col sm:flex-row justify-center gap-4 mb-12">
              <Link to="/signup/founder">
                <Button 
                  size="lg" 
                  className="bg-gold-500 text-white hover:bg-gold-400"
                >
                  Join as Founder
                  <ArrowRight size={18} className="ml-2" />
                </Button>
              </Link>
              <Link to="/signup/investor">
                <Button 
                  variant="outline" 
                  size="lg" 
                  className="border-gold-400 text-gold-400 hover:bg-gold-500/10"
                >
                  Join as Investor
                </Button>
              </Link>
            </div>
            
            <div className="grid grid-cols-3 gap-8 max-w-3xl mx-auto">
              <div className="text-center">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                  className="flex flex-col items-center"
                >
                  <span className="text-3xl font-bold text-white">
                    <CountUp
                      start={300}
                      end={500}
                      duration={4}
                      separator=","
                      suffix="+"
                      onEnd={() => ({shouldRepeat: true, delay: 0})}
                    />
                  </span>
                  <span className="text-sm text-primary-300">Startups</span>
                </motion.div>
              </div>
              <div className="text-center">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                  className="flex flex-col items-center"
                >
                  <span className="text-3xl font-bold text-white">
                    <CountUp
                      start={100}
                      end={200}
                      duration={4}
                      separator=","
                      suffix="+"
                      onEnd={() => ({shouldRepeat: true, delay: 0})}
                    />
                  </span>
                  <span className="text-sm text-primary-300">Investors</span>
                </motion.div>
              </div>
              <div className="text-center">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 }}
                  className="flex flex-col items-center"
                >
                  <span className="text-3xl font-bold text-white">₹
                    <CountUp
                      start={10}
                      end={20}
                      duration={4}
                      suffix="Cr+"
                      onEnd={() => ({shouldRepeat: true, delay: 0})}
                    />
                  </span>
                  <span className="text-sm text-primary-300">Funded</span>
                </motion.div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}