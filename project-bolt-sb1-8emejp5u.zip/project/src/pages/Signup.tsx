import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import Layout from '../components/layout/Layout';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import { User, Briefcase } from 'lucide-react';

export default function Signup() {
  const navigate = useNavigate();
  
  return (
    <Layout noFooter>
      <div className="min-h-screen bg-primary-50 pt-20 pb-12 flex flex-col items-center justify-center">
        <div className="w-full max-w-3xl px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center mb-12"
          >
            <img 
              src="https://assets.bolt.new/d7e65b96-ae90-4de4-8e71-5ab2dfd8c173" 
              alt="Dream Intake" 
              className="h-16 mx-auto mb-6" 
            />
            <h1 className="text-3xl font-bold text-primary-900 mb-3">Join Dream Intake</h1>
            <p className="text-xl text-primary-600 max-w-2xl mx-auto">
              Create your account and be part of the platform where dreams get funded
            </p>
          </motion.div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              <Card className="h-full flex flex-col">
                <div className="p-8 flex flex-col items-center text-center flex-grow">
                  <div className="w-16 h-16 bg-gold-100 rounded-full flex items-center justify-center mb-6">
                    <Briefcase size={32} className="text-gold-600" />
                  </div>
                  
                  <h2 className="text-2xl font-bold text-primary-900 mb-3">I'm a Founder</h2>
                  <p className="text-primary-600 mb-6">
                    Looking to secure funding for your startup? Join as a founder to showcase your idea and connect with potential investors.
                  </p>
                  
                  <ul className="text-left text-primary-700 space-y-2 mb-8 flex-grow">
                    <li className="flex items-start">
                      <svg className="h-5 w-5 text-gold-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                      Create a detailed startup profile
                    </li>
                    <li className="flex items-start">
                      <svg className="h-5 w-5 text-gold-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                      Upload a pitch video for investors
                    </li>
                    <li className="flex items-start">
                      <svg className="h-5 w-5 text-gold-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                      Connect with interested investors
                    </li>
                    <li className="flex items-start">
                      <svg className="h-5 w-5 text-gold-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                      Boost visibility with trending feature
                    </li>
                  </ul>
                  
                  <div className="border-t border-primary-100 pt-4 text-primary-700">
                    <span className="font-medium">Registration Fee:</span> ₹1 only
                  </div>
                </div>
                
                <div className="px-8 pb-8 pt-4">
                  <Button
                    onClick={() => navigate('/signup/founder')}
                    fullWidth
                  >
                    Join as Founder
                  </Button>
                </div>
              </Card>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <Card className="h-full flex flex-col">
                <div className="p-8 flex flex-col items-center text-center flex-grow">
                  <div className="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center mb-6">
                    <User size={32} className="text-primary-600" />
                  </div>
                  
                  <h2 className="text-2xl font-bold text-primary-900 mb-3">I'm an Investor</h2>
                  <p className="text-primary-600 mb-6">
                    Looking to invest in promising startups? Join as an investor to discover innovative ideas and connect with passionate founders.
                  </p>
                  
                  <ul className="text-left text-primary-700 space-y-2 mb-8 flex-grow">
                    <li className="flex items-start">
                      <svg className="h-5 w-5 text-gold-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                      Browse through curated startups
                    </li>
                    <li className="flex items-start">
                      <svg className="h-5 w-5 text-gold-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                      Filter startups by industry and location
                    </li>
                    <li className="flex items-start">
                      <svg className="h-5 w-5 text-gold-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                      Direct messaging with promising founders
                    </li>
                    <li className="flex items-start">
                      <svg className="h-5 w-5 text-gold-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                      Track investment interests and opportunities
                    </li>
                  </ul>
                  
                  <div className="border-t border-primary-100 pt-4 text-primary-700">
                    <span className="font-medium">Registration Fee:</span> ₹99 only
                  </div>
                </div>
                
                <div className="px-8 pb-8 pt-4">
                  <Button
                    onClick={() => navigate('/signup/investor')}
                    variant="outline"
                    fullWidth
                  >
                    Join as Investor
                  </Button>
                </div>
              </Card>
            </motion.div>
          </div>
          
          <div className="mt-8 text-center">
            <p className="text-primary-600">
              Already have an account?{' '}
              <Link to="/login" className="font-medium text-gold-500 hover:text-gold-600">
                Sign in
              </Link>
            </p>
          </div>
        </div>
      </div>
    </Layout>
  );
}