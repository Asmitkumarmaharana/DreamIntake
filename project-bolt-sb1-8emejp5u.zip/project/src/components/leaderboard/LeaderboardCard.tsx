import React from 'react';
import { motion } from 'framer-motion';
import { Heart, Eye, TrendingUp, ArrowUpRight } from 'lucide-react';
import { Startup } from '../../types';
import Button from '../ui/Button';

interface LeaderboardCardProps {
  startup: Startup;
  position: number;
  onClick: () => void;
}

export default function LeaderboardCard({ startup, position, onClick }: LeaderboardCardProps) {
  // Determine medal color for top 3
  const getMedalColor = (position: number) => {
    switch (position) {
      case 1:
        return 'bg-yellow-500';
      case 2:
        return 'bg-gray-300';
      case 3:
        return 'bg-amber-600';
      default:
        return 'bg-primary-200';
    }
  };
  
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: position * 0.1 }}
      whileHover={{ y: -5 }}
      className={`
        relative overflow-hidden bg-white rounded-xl shadow-card
        ${position <= 3 ? 'border-2 border-gold-300' : 'border border-primary-200'}
      `}
    >
      {/* Position indicator */}
      <div className="absolute top-0 left-0 w-12 h-12">
        <div className={`absolute top-0 left-0 w-24 h-24 -rotate-45 -translate-x-12 -translate-y-12 ${getMedalColor(position)}`}></div>
        <span className="absolute top-1 left-2 text-white font-bold text-sm">{position}</span>
      </div>
      
      {/* Trending badge */}
      {startup.isBoosted && (
        <div className="absolute top-3 right-3 bg-gold-500 text-white text-xs font-bold px-3 py-1 rounded-full flex items-center">
          <TrendingUp size={12} className="mr-1" />
          TRENDING
        </div>
      )}
      
      <div className="p-6 pt-9">
        <h3 className="text-xl font-bold text-primary-900 mb-2">{startup.startupName}</h3>
        
        <div className="flex items-center mb-4">
          <div className="h-8 w-8 rounded-full bg-primary-200 flex items-center justify-center text-primary-800 font-medium mr-2">
            {startup.founderName.charAt(0)}
          </div>
          <span className="text-sm font-medium text-primary-700">{startup.founderName}</span>
          <span className="mx-2 text-primary-400">•</span>
          <span className="text-sm text-primary-500">{startup.location}</span>
        </div>
        
        <p className="text-primary-600 mb-4">{startup.shortPitch}</p>
        
        <div className="flex flex-wrap gap-2 mb-4">
          {startup.industries.map((industry, index) => (
            <span 
              key={index} 
              className="text-xs bg-primary-100 text-primary-700 px-2 py-1 rounded-full"
            >
              {industry}
            </span>
          ))}
        </div>
        
        <div className="flex items-center justify-between mt-6">
          <div className="flex items-center space-x-6">
            <div className="flex items-center text-primary-500">
              <Heart size={18} className="mr-1 text-error-500" />
              <span className="font-semibold">{startup.likes}</span>
            </div>
            
            <div className="flex items-center text-primary-500">
              <Eye size={18} className="mr-1" />
              <span>{startup.views}</span>
            </div>
          </div>
          
          <Button size="sm" onClick={onClick}>
            View Details
            <ArrowUpRight size={14} className="ml-1" />
          </Button>
        </div>
      </div>
    </motion.div>
  );
}