import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import Layout from '../components/layout/Layout';
import StartupCard from '../components/discover/StartupCard';
import { useStartupStore } from '../store/startupStore';
import { Startup } from '../types';
import { INDUSTRIES, LOCATIONS } from '../utils/mockData';

export default function Trending() {
  const { startups, fetchStartups, isLoading } = useStartupStore();
  const [selectedIndustry, setSelectedIndustry] = useState<string>('All');
  const [selectedLocation, setSelectedLocation] = useState<string>('All');
  const [selectedStartup, setSelectedStartup] = useState<Startup | null>(null);
  
  useEffect(() => {
    document.title = 'Trending Startups | Dream Intake';
    fetchStartups();
  }, [fetchStartups]);
  
  // Filter trending startups
  const trendingStartups = startups.filter(startup => startup.isBoosted);
  
  // Apply filters
  const filteredStartups = trendingStartups.filter(startup => {
    const matchesIndustry = selectedIndustry === 'All' || 
      startup.industries.includes(selectedIndustry);
    const matchesLocation = selectedLocation === 'All' || 
      startup.location === selectedLocation;
    return matchesIndustry && matchesLocation;
  });
  
  const handleStartupClick = (startup: Startup) => {
    setSelectedStartup(startup);
    document.body.style.overflow = 'hidden';
  };
  
  const closeModal = () => {
    setSelectedStartup(null);
    document.body.style.overflow = 'auto';
  };
  
  return (
    <Layout>
      <div className="pt-20 pb-20 bg-primary-50 min-h-screen">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center mb-12"
          >
            <h1 className="text-4xl sm:text-5xl font-serif font-bold text-primary-900 mb-4">
              Trending <span className="text-gold-500">Startups</span>
            </h1>
            <p className="text-xl text-primary-600 max-w-3xl mx-auto">
              Discover the hottest startups making waves in the ecosystem
            </p>
          </motion.div>
          
          {/* Filters */}
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-primary-700 mb-2">
                  Industry
                </label>
                <select
                  value={selectedIndustry}
                  onChange={(e) => setSelectedIndustry(e.target.value)}
                  className="w-full rounded-lg border border-primary-300 py-2 px-3 focus:ring-2 focus:ring-gold-500 focus:border-transparent"
                >
                  <option value="All">All Industries</option>
                  {INDUSTRIES.map(industry => (
                    <option key={industry} value={industry}>{industry}</option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-primary-700 mb-2">
                  Location
                </label>
                <select
                  value={selectedLocation}
                  onChange={(e) => setSelectedLocation(e.target.value)}
                  className="w-full rounded-lg border border-primary-300 py-2 px-3 focus:ring-2 focus:ring-gold-500 focus:border-transparent"
                >
                  <option value="All">All Locations</option>
                  {LOCATIONS.map(location => (
                    <option key={location} value={location}>{location}</option>
                  ))}
                </select>
              </div>
            </div>
          </div>
          
          {isLoading ? (
            <div className="flex justify-center py-20">
              <div className="animate-spin h-12 w-12 border-4 border-gold-500 rounded-full border-t-transparent"></div>
            </div>
          ) : filteredStartups.length === 0 ? (
            <div className="text-center py-20">
              <h3 className="text-2xl font-semibold text-primary-900 mb-2">No trending startups found</h3>
              <p className="text-primary-600">Try adjusting your filters to see more results</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredStartups.map((startup, index) => (
                <motion.div
                  key={startup.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: index * 0.1 }}
                >
                  <StartupCard
                    startup={startup}
                    onClick={() => handleStartupClick(startup)}
                  />
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </div>
      
      {/* Startup detail modal */}
      {selectedStartup && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4"
          onClick={closeModal}
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-xl shadow-xl max-w-3xl w-full max-h-[90vh] overflow-y-auto"
            onClick={e => e.stopPropagation()}
          >
            {selectedStartup.pitchVideoUrl && (
              <div className="aspect-video bg-primary-900 relative">
                <video
                  src={selectedStartup.pitchVideoUrl}
                  controls
                  className="w-full h-full object-cover"
                />
              </div>
            )}
            
            <div className="p-6 sm:p-8">
              <div className="flex items-start justify-between mb-6">
                <div>
                  <h2 className="text-2xl sm:text-3xl font-bold text-primary-900 mb-2">
                    {selectedStartup.startupName}
                  </h2>
                  <div className="flex items-center">
                    <div className="h-8 w-8 rounded-full bg-primary-200 flex items-center justify-center text-primary-800 font-medium mr-2">
                      {selectedStartup.founderName.charAt(0)}
                    </div>
                    <span className="text-sm font-medium text-primary-700">
                      {selectedStartup.founderName}
                    </span>
                    <span className="mx-2 text-primary-400">•</span>
                    <span className="text-sm text-primary-500">
                      {selectedStartup.location}
                    </span>
                  </div>
                </div>
                
                <button 
                  onClick={closeModal}
                  className="text-primary-500 hover:text-primary-700"
                >
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path>
                  </svg>
                </button>
              </div>
              
              <div className="flex flex-wrap gap-2 mb-6">
                {selectedStartup.industries.map((industry, index) => (
                  <span 
                    key={index} 
                    className="text-sm bg-primary-100 text-primary-700 px-3 py-1 rounded-full"
                  >
                    {industry}
                  </span>
                ))}
              </div>
              
              <div className="mb-8">
                <h3 className="text-xl font-semibold text-primary-900 mb-3">
                  About the Startup
                </h3>
                <p className="text-primary-700 whitespace-pre-line">
                  {selectedStartup.fullPitch}
                </p>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-4">
                <button className="flex-1 bg-gold-500 text-white py-3 px-6 rounded-lg font-medium hover:bg-gold-600 transition-colors">
                  Contact Founder
                </button>
                <button className="flex-1 border border-primary-300 text-primary-800 py-3 px-6 rounded-lg font-medium hover:bg-primary-50 transition-colors">
                  Express Interest
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </Layout>
  );
}