import React from 'react';
import Layout from '../components/layout/Layout';
import InvestorForm from '../components/signup/InvestorForm';

export default function SignupInvestor() {
  React.useEffect(() => {
    document.title = 'Investor Signup | Dream Intake';
  }, []);
  
  return (
    <Layout noFooter>
      <div className="min-h-screen bg-primary-50 pt-20 pb-12 flex flex-col items-center justify-center">
        <div className="container mx-auto px-4 max-w-lg">
          <InvestorForm />
        </div>
      </div>
    </Layout>
  );
}