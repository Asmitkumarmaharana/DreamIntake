import React from 'react';
import { motion } from 'framer-motion';
import Layout from '../components/layout/Layout';
import Card from '../components/ui/Card';
import { Calendar, Clock, ArrowRight } from 'lucide-react';

export default function Blog() {
  React.useEffect(() => {
    document.title = 'Blog | Dream Intake';
  }, []);

  const blogPosts = [
    {
      id: 1,
      title: "How to Create a Winning Pitch Deck",
      excerpt: "Learn the essential elements of a pitch deck that captures investor attention and helps secure funding for your startup.",
      category: "Startup Tips",
      author: "Priya Sharma",
      date: "2024-02-15",
      readTime: "8 min read",
      image: "https://images.pexels.com/photos/7681091/pexels-photo-7681091.jpeg",
    },
    {
      id: 2,
      title: "Understanding Startup Valuation",
      excerpt: "A comprehensive guide to startup valuation methods and what investors look for when evaluating early-stage companies.",
      category: "Investment",
      author: "Rohit Mehta",
      date: "2024-02-10",
      readTime: "12 min read",
      image: "https://images.pexels.com/photos/6801648/pexels-photo-6801648.jpeg",
    },
    {
      id: 3,
      title: "Building a Strong Founding Team",
      excerpt: "Tips for assembling and managing a founding team that can drive your startup's success and attract investment.",
      category: "Team Building",
      author: "Vikram Singh",
      date: "2024-02-05",
      readTime: "10 min read",
      image: "https://images.pexels.com/photos/3183150/pexels-photo-3183150.jpeg",
    },
    {
      id: 4,
      title: "Navigating Term Sheets",
      excerpt: "A beginner's guide to understanding term sheets and negotiating favorable investment terms for your startup.",
      category: "Legal",
      author: "Ananya Desai",
      date: "2024-01-30",
      readTime: "15 min read",
      image: "https://images.pexels.com/photos/955389/pexels-photo-955389.jpeg",
    },
    {
      id: 5,
      title: "Marketing Your Startup on a Budget",
      excerpt: "Creative and cost-effective marketing strategies to help your startup gain traction without breaking the bank.",
      category: "Marketing",
      author: "Arjun Patel",
      date: "2024-01-25",
      readTime: "9 min read",
      image: "https://images.pexels.com/photos/935979/pexels-photo-935979.jpeg",
    },
    {
      id: 6,
      title: "The Art of Bootstrapping",
      excerpt: "Learn how successful startups have bootstrapped their way to success and when to consider external funding.",
      category: "Finance",
      author: "Neha Kapoor",
      date: "2024-01-20",
      readTime: "11 min read",
      image: "https://images.pexels.com/photos/3182826/pexels-photo-3182826.jpeg",
    }
  ];

  return (
    <Layout>
      <div className="pt-20 pb-20 bg-primary-50 min-h-screen">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center mb-12"
          >
            <h1 className="text-4xl sm:text-5xl font-serif font-bold text-primary-900 mb-4">
              Dream Intake <span className="text-gold-500">Blog</span>
            </h1>
            <p className="text-xl text-primary-600 max-w-3xl mx-auto">
              Insights, tips, and stories from the startup ecosystem
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {blogPosts.map((post, index) => (
              <motion.div
                key={post.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
              >
                <Card className="h-full flex flex-col overflow-hidden group cursor-pointer">
                  <div className="relative h-48 overflow-hidden">
                    <img
                      src={post.image}
                      alt={post.title}
                      className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute top-4 left-4">
                      <span className="bg-white/90 backdrop-blur-sm text-primary-900 text-xs font-medium px-2 py-1 rounded-full">
                        {post.category}
                      </span>
                    </div>
                  </div>

                  <div className="p-6 flex-grow flex flex-col">
                    <div className="flex items-center text-sm text-primary-500 mb-3">
                      <Calendar size={14} className="mr-1" />
                      <span>{new Date(post.date).toLocaleDateString('en-US', { 
                        month: 'long',
                        day: 'numeric',
                        year: 'numeric'
                      })}</span>
                      <span className="mx-2">•</span>
                      <Clock size={14} className="mr-1" />
                      <span>{post.readTime}</span>
                    </div>

                    <h2 className="text-xl font-bold text-primary-900 mb-2 group-hover:text-gold-500 transition-colors">
                      {post.title}
                    </h2>
                    <p className="text-primary-600 mb-4 flex-grow">
                      {post.excerpt}
                    </p>

                    <div className="flex items-center justify-between mt-4">
                      <span className="text-sm font-medium text-primary-700">
                        By {post.author}
                      </span>
                      <span className="text-gold-500 group-hover:text-gold-600 flex items-center text-sm font-medium">
                        Read More
                        <ArrowRight size={16} className="ml-1 transform group-hover:translate-x-1 transition-transform" />
                      </span>
                    </div>
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </Layout>
  );
}