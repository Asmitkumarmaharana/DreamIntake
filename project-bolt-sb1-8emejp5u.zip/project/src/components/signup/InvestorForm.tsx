import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import Button from '../ui/Button';
import Input from '../ui/Input';
import QRCodeDisplay from '../ui/QRCodeDisplay';
import { INDUSTRIES, LOCATIONS } from '../../utils/mockData';
import { useAuthStore } from '../../store/authStore';

export default function InvestorForm() {
  const navigate = useNavigate();
  const { signupInvestor, isLoading, error } = useAuthStore();
  
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    industries: [] as string[],
    location: '',
  });
  
  const [hasCompleted, setHasCompleted] = useState(false);
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const toggleIndustry = (industry: string) => {
    const currentIndustries = formData.industries;
    const updatedIndustries = currentIndustries.includes(industry)
      ? currentIndustries.filter(i => i !== industry)
      : [...currentIndustries, industry];
    
    setFormData(prev => ({ ...prev, industries: updatedIndustries }));
  };
  
  const handlePaymentComplete = () => {
    setHasCompleted(true);
    setTimeout(() => {
      setStep(2);
    }, 1500);
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      await signupInvestor(
        formData.name,
        formData.email,
        formData.industries,
        formData.location
      );
      
      navigate('/discover');
    } catch (error) {
      console.error('Signup failed:', error);
    }
  };
  
  return (
    <div className="w-full max-w-md mx-auto">
      {step === 1 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.3 }}
        >
          <h2 className="text-2xl font-bold text-primary-900 mb-2">Complete Payment</h2>
          <p className="text-primary-600 mb-6">
            Pay ₹99 to access our curated network of innovative startups.
          </p>
          
          <QRCodeDisplay 
            amount={99} 
            description="One-time investor registration fee"
          />
          
          <div className="mt-8 flex justify-between">
            <Button variant="outline" onClick={() => navigate('/signup')}>
              Back
            </Button>
            
            <Button onClick={handlePaymentComplete} disabled={hasCompleted}>
              {hasCompleted ? 'Payment Verified ✓' : 'I have paid'}
            </Button>
          </div>
        </motion.div>
      )}
      
      {step === 2 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.3 }}
        >
          <h2 className="text-2xl font-bold text-primary-900 mb-2">Investor Details</h2>
          <p className="text-primary-600 mb-6">
            Tell us more about your investment interests.
          </p>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            <Input
              label="Full Name"
              type="text"
              name="name"
              value={formData.name}
              onChange={handleChange}
              placeholder="Your full name"
              required
              fullWidth
            />
            
            <Input
              label="Email Address"
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              placeholder="you@example.com"
              required
              fullWidth
            />
            
            <Input
              label="Password"
              type="password"
              name="password"
              value={formData.password}
              onChange={handleChange}
              placeholder="Choose a strong password"
              required
              fullWidth
            />
            
            <div>
              <label className="block text-sm font-medium text-primary-700 mb-1">
                Industry Interests
              </label>
              <div className="flex flex-wrap gap-2 mt-2">
                {INDUSTRIES.map(industry => (
                  <button
                    type="button"
                    key={industry}
                    onClick={() => toggleIndustry(industry)}
                    className={`
                      text-sm px-3 py-1.5 rounded-full border transition-colors
                      ${formData.industries.includes(industry) 
                        ? 'bg-gold-500 text-white border-gold-500' 
                        : 'bg-white text-primary-700 border-primary-300 hover:bg-primary-50'}
                    `}
                  >
                    {industry}
                  </button>
                ))}
              </div>
              {formData.industries.length === 0 && (
                <p className="text-xs text-primary-500 mt-1">
                  Select at least one industry that interests you
                </p>
              )}
            </div>
            
            <div>
              <label className="block text-sm font-medium text-primary-700 mb-1">
                Location
              </label>
              <select
                name="location"
                value={formData.location}
                onChange={handleChange}
                className="block w-full rounded-lg border border-primary-300 px-4 py-2.5 text-primary-900 focus:outline-none focus:ring-2 focus:ring-gold-500 focus:ring-opacity-50 focus:border-transparent"
                required
              >
                <option value="" disabled>Select your primary location</option>
                {LOCATIONS.map(location => (
                  <option key={location} value={location}>{location}</option>
                ))}
              </select>
            </div>
            
            {error && (
              <p className="text-error-500 text-sm">{error}</p>
            )}
            
            <div className="flex justify-between mt-8">
              <Button variant="outline" onClick={() => setStep(1)}>
                Back
              </Button>
              
              <Button 
                type="submit" 
                isLoading={isLoading} 
                disabled={formData.industries.length === 0}
              >
                Complete Registration
              </Button>
            </div>
          </form>
        </motion.div>
      )}
    </div>
  );
}