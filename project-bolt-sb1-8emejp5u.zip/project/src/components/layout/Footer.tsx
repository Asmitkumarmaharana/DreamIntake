import React from 'react';
import { Link } from 'react-router-dom';
import { Linkedin, Instagram, Facebook, X } from 'lucide-react';

export default function Footer() {
  const socialLinks = [
    {
      icon: X,
      url: 'https://twitter.com/dreamintake',
      label: 'Follow us on Twitter'
    },
    {
      icon: Linkedin,
      url: 'https://linkedin.com/company/dreamintake',
      label: 'Connect with us on LinkedIn'
    },
    {
      icon: Instagram,
      url: 'https://www.instagram.com/dreamintake?igsh=Z3VzdnRrMnpsbG42',
      label: 'Follow us on Instagram'
    },
    {
      icon: Facebook,
      url: 'https://facebook.com/dreamintake',
      label: 'Like us on Facebook'
    }
  ];

  return (
    <footer className="bg-primary-900 text-white py-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-1">
            <Link to="/" className="inline-block mb-4">
              <div className="flex flex-col">
                <h1 className="text-2xl font-serif font-bold text-white">
                  Dream Intake
                </h1>
                <p className="text-xs text-gold-500 font-medium">
                  Where Dreams Get Funded
                </p>
              </div>
            </Link>
            <p className="text-primary-300 mb-4">
              Connecting visionary founders with forward-thinking investors to bring dreams to life.
            </p>
            <div className="flex space-x-4">
              {socialLinks.map((social, index) => {
                const Icon = social.icon;
                return (
                  <a
                    key={index}
                    href={social.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label={social.label}
                    className="text-primary-400 hover:text-gold-400 transition-colors duration-200 transform hover:scale-110"
                  >
                    <Icon size={20} />
                  </a>
                );
              })}
            </div>
          </div>
          
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider text-gold-400 mb-4">
              Platform
            </h3>
            <ul className="space-y-2">
              <li>
                <Link to="/discover" className="text-primary-300 hover:text-white transition-colors">
                  Discover Startups
                </Link>
              </li>
              <li>
                <Link to="/trending" className="text-primary-300 hover:text-white transition-colors">
                  Trending
                </Link>
              </li>
              <li>
                <Link to="/leaderboard" className="text-primary-300 hover:text-white transition-colors">
                  Leaderboard
                </Link>
              </li>
              <li>
                <Link to="/faq" className="text-primary-300 hover:text-white transition-colors">
                  FAQs
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider text-gold-400 mb-4">
              Resources
            </h3>
            <ul className="space-y-2">
              <li>
                <Link to="/founder-resources" className="text-primary-300 hover:text-white transition-colors">
                  Founder Resources
                </Link>
              </li>
              <li>
                <Link to="/investor-guidelines" className="text-primary-300 hover:text-white transition-colors">
                  Investor Guidelines
                </Link>
              </li>
              <li>
                <Link to="/blog" className="text-primary-300 hover:text-white transition-colors">
                  Blog
                </Link>
              </li>
              <li>
                <Link to="/faq" className="text-primary-300 hover:text-white transition-colors">
                  FAQs
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider text-gold-400 mb-4">
              Legal
            </h3>
            <ul className="space-y-2">
              <li>
                <Link to="/privacy-policy" className="text-primary-300 hover:text-white transition-colors">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link to="/terms" className="text-primary-300 hover:text-white transition-colors">
                  Terms of Service
                </Link>
              </li>
              <li>
                <Link to="/cookie-policy" className="text-primary-300 hover:text-white transition-colors">
                  Cookie Policy
                </Link>
              </li>
              <li>
                <Link to="/contact" className="text-primary-300 hover:text-white transition-colors">
                  Contact Us
                </Link>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-primary-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-primary-400 text-sm">
            &copy; {new Date().getFullYear()} Dream Intake. All rights reserved.
          </p>
          <p className="text-primary-400 text-sm mt-4 md:mt-0">
            Made with ❤️ in India
          </p>
        </div>
      </div>
    </footer>
  );
}