import React, { useEffect } from 'react';
import { motion } from 'framer-motion';
import Layout from '../components/layout/Layout';
import LeaderboardCard from '../components/leaderboard/LeaderboardCard';
import { useStartupStore } from '../store/startupStore';
import { Startup } from '../types';

export default function Leaderboard() {
  const { fetchStartups, startups, isLoading } = useStartupStore();
  
  useEffect(() => {
    document.title = 'Startup Leaderboard | Dream Intake';
    fetchStartups();
  }, [fetchStartups]);
  
  // Sort startups by different metrics
  const sortByLikes = [...startups].sort((a, b) => b.likes - a.likes).slice(0, 10);
  const sortByViews = [...startups].sort((a, b) => b.views - a.views).slice(0, 10);
  const boostedStartups = startups.filter(s => s.isBoosted);
  
  // Handler for startup click
  const handleStartupClick = (startup: Startup) => {
    // Implementation would open a modal or navigate to detail page
    console.log('Startup clicked:', startup);
  };
  
  return (
    <Layout>
      <div className="pt-20 pb-20 bg-primary-50 min-h-screen">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="mb-12 text-center"
          >
            <h1 className="text-4xl sm:text-5xl font-bold text-primary-900 mb-4">
              Startup <span className="text-gold-500">Leaderboard</span>
            </h1>
            <p className="text-xl text-primary-600 max-w-3xl mx-auto">
              Discover the most promising startups ranked by investor interest and engagement metrics
            </p>
          </motion.div>
          
          {isLoading ? (
            <div className="flex justify-center py-20">
              <div className="animate-spin h-12 w-12 border-4 border-gold-500 rounded-full border-t-transparent"></div>
            </div>
          ) : (
            <div className="space-y-16">
              {/* Top Liked Startups */}
              <section>
                <div className="flex items-center mb-8">
                  <motion.div
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.5 }}
                    className="bg-gold-500 text-white p-2 rounded-full mr-4"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                    </svg>
                  </motion.div>
                  <h2 className="text-2xl sm:text-3xl font-bold text-primary-900">Most Liked Startups</h2>
                </div>
                
                <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                  {sortByLikes.slice(0, 3).map((startup, index) => (
                    <LeaderboardCard
                      key={startup.id}
                      startup={startup}
                      position={index + 1}
                      onClick={() => handleStartupClick(startup)}
                    />
                  ))}
                </div>
                
                <div className="mt-8 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                  {sortByLikes.slice(3, 9).map((startup, index) => (
                    <div key={startup.id} className="p-4 bg-white rounded-lg shadow-sm flex items-center">
                      <div className="w-8 h-8 rounded-full bg-primary-100 flex items-center justify-center mr-3">
                        <span className="font-semibold text-primary-700">{index + 4}</span>
                      </div>
                      <div className="flex-grow">
                        <h3 className="font-medium text-primary-900">{startup.startupName}</h3>
                        <p className="text-sm text-primary-500">{startup.likes} likes</p>
                      </div>
                    </div>
                  ))}
                </div>
              </section>
              
              {/* Most Viewed Startups */}
              <section>
                <div className="flex items-center mb-8">
                  <motion.div
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.5, delay: 0.2 }}
                    className="bg-primary-800 text-white p-2 rounded-full mr-4"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                    </svg>
                  </motion.div>
                  <h2 className="text-2xl sm:text-3xl font-bold text-primary-900">Most Viewed Startups</h2>
                </div>
                
                <div className="grid gap-6 grid-cols-1 md:grid-cols-2">
                  {sortByViews.slice(0, 6).map((startup, index) => (
                    <div key={startup.id} className="bg-white p-5 rounded-lg shadow-sm flex items-center">
                      <div className={`
                        w-10 h-10 rounded-full flex items-center justify-center mr-4 font-bold
                        ${index < 3 ? 'bg-gold-100 text-gold-800' : 'bg-primary-100 text-primary-700'}
                      `}>
                        {index + 1}
                      </div>
                      <div className="flex-grow">
                        <h3 className="font-medium text-primary-900 text-lg">{startup.startupName}</h3>
                        <p className="text-primary-600">{startup.shortPitch.substring(0, 60)}...</p>
                        <div className="flex items-center mt-2">
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-primary-500 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                          </svg>
                          <span className="text-sm text-primary-500">{startup.views} views</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </section>
              
              {/* Trending Startups (Boosted) */}
              {boostedStartups.length > 0 && (
                <section>
                  <div className="flex items-center mb-8">
                    <motion.div
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ duration: 0.5, delay: 0.4 }}
                      className="bg-error-500 text-white p-2 rounded-full mr-4"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                      </svg>
                    </motion.div>
                    <h2 className="text-2xl sm:text-3xl font-bold text-primary-900">Trending Startups</h2>
                  </div>
                  
                  <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                    {boostedStartups.map((startup, index) => (
                      <motion.div
                        key={startup.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.3, delay: index * 0.1 }}
                        className="bg-white rounded-lg shadow-card overflow-hidden border-2 border-gold-300"
                      >
                        <div className="p-1 bg-gradient-to-r from-gold-400 to-gold-600"></div>
                        <div className="p-5">
                          <div className="flex items-center justify-between mb-3">
                            <h3 className="font-bold text-primary-900 text-lg">{startup.startupName}</h3>
                            <span className="bg-gold-100 text-gold-800 text-xs px-2 py-1 rounded-full flex items-center">
                              <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                              </svg>
                              TRENDING
                            </span>
                          </div>
                          <p className="text-primary-600 mb-3">{startup.shortPitch.substring(0, 100)}...</p>
                          <div className="flex items-center justify-between">
                            <div className="flex items-center text-sm text-primary-500">
                              <span className="mr-3">{startup.likes} likes</span>
                              <span>{startup.views} views</span>
                            </div>
                            <button 
                              onClick={() => handleStartupClick(startup)}
                              className="text-gold-500 hover:text-gold-700 font-medium text-sm"
                            >
                              View Details
                            </button>
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </section>
              )}
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
}