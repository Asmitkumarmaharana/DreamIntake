import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Lightbulb, ArrowRight } from 'lucide-react';
import Button from '../ui/Button';
import Input from '../ui/Input';
import QRCodeDisplay from '../ui/QRCodeDisplay';

interface PitchStartupModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: any) => void;
}

export default function PitchStartupModal({ isOpen, onClose, onSubmit }: PitchStartupModalProps) {
  const [step, setStep] = useState(1);
  const [isPaymentVerified, setIsPaymentVerified] = useState(false);
  const [formData, setFormData] = useState({
    startupName: '',
    description: '',
    pitchVideoUrl: '',
    industries: [] as string[],
  });

  const handlePaymentVerified = () => {
    setIsPaymentVerified(true);
    setTimeout(() => setStep(2), 1500);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4"
        >
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.95, opacity: 0 }}
            className="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto"
          >
            <div className="p-6 border-b border-primary-100 flex items-center justify-between">
              <div className="flex items-center">
                <Lightbulb className="w-6 h-6 text-gold-500 mr-2" />
                <h2 className="text-2xl font-bold text-primary-900">
                  Pitch Another Startup
                </h2>
              </div>
              <button
                onClick={onClose}
                className="text-primary-500 hover:text-primary-700"
              >
                <X size={24} />
              </button>
            </div>

            <div className="p-6">
              {step === 1 ? (
                <div className="text-center">
                  <h3 className="text-xl font-semibold text-primary-900 mb-4">
                    Complete Payment
                  </h3>
                  <p className="text-primary-600 mb-8">
                    Pay ₹1 to submit another startup pitch and get noticed by investors.
                  </p>

                  <QRCodeDisplay
                    amount={1}
                    description="One-time startup pitch submission fee"
                  />

                  <div className="mt-8">
                    <Button
                      onClick={handlePaymentVerified}
                      disabled={isPaymentVerified}
                      fullWidth
                    >
                      {isPaymentVerified ? 'Payment Verified ✓' : 'I have paid'}
                    </Button>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6">
                  <Input
                    label="Startup Name"
                    value={formData.startupName}
                    onChange={(e) => setFormData({ ...formData, startupName: e.target.value })}
                    placeholder="Enter your startup name"
                    required
                    maxLength={100}
                    fullWidth
                  />

                  <div>
                    <label className="block text-sm font-medium text-primary-700 mb-1">
                      Description
                    </label>
                    <textarea
                      value={formData.description}
                      onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                      placeholder="Describe your startup idea..."
                      className="w-full rounded-lg border border-primary-300 px-4 py-2.5 text-primary-900 focus:outline-none focus:ring-2 focus:ring-gold-500 focus:border-transparent"
                      rows={5}
                      maxLength={1000}
                      required
                    />
                    <p className="mt-1 text-sm text-primary-500">
                      {formData.description.length}/1000 characters
                    </p>
                  </div>

                  <Input
                    label="Pitch Video URL"
                    type="url"
                    value={formData.pitchVideoUrl}
                    onChange={(e) => setFormData({ ...formData, pitchVideoUrl: e.target.value })}
                    placeholder="https://youtube.com/watch?v=..."
                    helperText="Add a link to your 1-2 minute pitch video"
                    required
                    fullWidth
                  />

                  <div className="flex justify-end space-x-4">
                    <Button variant="outline" onClick={() => setStep(1)}>
                      Back
                    </Button>
                    <Button type="submit">
                      Submit Pitch
                      <ArrowRight size={18} className="ml-2" />
                    </Button>
                  </div>
                </form>
              )}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}