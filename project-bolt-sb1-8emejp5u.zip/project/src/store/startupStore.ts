import { create } from 'zustand';
import { Startup } from '../types';
import { MOCK_STARTUPS } from '../utils/mockData';

interface StartupFilters {
  industries: string[];
  locations: string[];
  searchQuery: string;
}

interface StartupState {
  startups: Startup[];
  filteredStartups: Startup[];
  filters: StartupFilters;
  isLoading: boolean;
  error: string | null;
  fetchStartups: () => Promise<void>;
  likeStartup: (startupId: string) => void;
  boostStartup: (startupId: string) => Promise<void>;
  setFilters: (filters: Partial<StartupFilters>) => void;
}

export const useStartupStore = create<StartupState>((set, get) => ({
  startups: [],
  filteredStartups: [],
  filters: {
    industries: [],
    locations: [],
    searchQuery: '',
  },
  isLoading: false,
  error: null,
  
  fetchStartups: async () => {
    set({ isLoading: true, error: null });
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Use mock data for now
      set({ 
        startups: MOCK_STARTUPS,
        filteredStartups: MOCK_STARTUPS,
        isLoading: false 
      });
    } catch (error) {
      set({ error: 'Failed to fetch startups', isLoading: false });
    }
  },
  
  likeStartup: (startupId: string) => {
    const { startups } = get();
    
    const updatedStartups = startups.map(startup => 
      startup.id === startupId 
        ? { ...startup, likes: startup.likes + 1 } 
        : startup
    );
    
    set({ 
      startups: updatedStartups,
      filteredStartups: applyFilters(updatedStartups, get().filters)
    });
  },
  
  boostStartup: async (startupId: string) => {
    set({ isLoading: true, error: null });
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const { startups } = get();
      
      const updatedStartups = startups.map(startup => 
        startup.id === startupId 
          ? { 
              ...startup, 
              isBoosted: true,
              boostExpiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString()
            } 
          : startup
      );
      
      set({ 
        startups: updatedStartups,
        filteredStartups: applyFilters(updatedStartups, get().filters),
        isLoading: false
      });
    } catch (error) {
      set({ error: 'Failed to boost startup', isLoading: false });
    }
  },
  
  setFilters: (newFilters: Partial<StartupFilters>) => {
    const updatedFilters = {
      ...get().filters,
      ...newFilters
    };
    
    set({ 
      filters: updatedFilters,
      filteredStartups: applyFilters(get().startups, updatedFilters)
    });
  },
}));

// Helper function to apply filters
function applyFilters(startups: Startup[], filters: StartupFilters): Startup[] {
  return startups.filter(startup => {
    // Filter by industries
    if (filters.industries.length > 0 && 
        !startup.industries.some(ind => filters.industries.includes(ind))) {
      return false;
    }
    
    // Filter by location
    if (filters.locations.length > 0 && 
        !filters.locations.includes(startup.location)) {
      return false;
    }
    
    // Filter by search query
    if (filters.searchQuery && 
        !startup.startupName.toLowerCase().includes(filters.searchQuery.toLowerCase()) &&
        !startup.shortPitch.toLowerCase().includes(filters.searchQuery.toLowerCase())) {
      return false;
    }
    
    return true;
  });
}