import React, { useState } from 'react';
import { motion } from 'framer-motion';
import Layout from '../components/layout/Layout';
import Button from '../components/ui/Button';
import Input from '../components/ui/Input';
import { Mail, Send } from 'lucide-react';

export default function Contact() {
  React.useEffect(() => {
    document.title = 'Contact Us | Dream Intake';
  }, []);

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    setIsSubmitting(false);
    setSubmitSuccess(true);
    setFormData({ name: '', email: '', subject: '', message: '' });

    // Reset success message after 3 seconds
    setTimeout(() => setSubmitSuccess(false), 3000);
  };

  return (
    <Layout>
      <div className="pt-20 pb-20 bg-primary-50 min-h-screen">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center mb-12"
          >
            <h1 className="text-4xl sm:text-5xl font-serif font-bold text-primary-900 mb-4">
              Get in <span className="text-gold-500">Touch</span>
            </h1>
            <p className="text-xl text-primary-600 max-w-3xl mx-auto">
              Have questions? We're here to help and provide you with the support you need
            </p>
          </motion.div>

          <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Contact Information */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="bg-white rounded-lg shadow-md p-8"
            >
              <h2 className="text-2xl font-bold text-primary-900 mb-6">Contact Information</h2>
              
              <div className="flex items-start">
                <div className="w-12 h-12 bg-gold-100 rounded-lg flex items-center justify-center mr-4">
                  <Mail className="text-gold-500" size={24} />
                </div>
                <div>
                  <h3 className="font-medium text-primary-900 mb-1">Email</h3>
                  <a href="mailto:dreamintakeco@gmail.com" className="text-primary-600 hover:text-gold-500 transition-colors">
                    dreamintakeco@gmail.com
                  </a>
                </div>
              </div>
            </motion.div>

            {/* Contact Form */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="bg-white rounded-lg shadow-md p-8"
            >
              <h2 className="text-2xl font-bold text-primary-900 mb-6">Send us a Message</h2>
              
              <form onSubmit={handleSubmit} className="space-y-6">
                <Input
                  label="Full Name"
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  placeholder="Your name"
                  required
                  fullWidth
                />

                <Input
                  label="Email Address"
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="you@example.com"
                  required
                  fullWidth
                />

                <Input
                  label="Subject"
                  type="text"
                  name="subject"
                  value={formData.subject}
                  onChange={handleChange}
                  placeholder="How can we help?"
                  required
                  fullWidth
                />

                <div>
                  <label className="block text-sm font-medium text-primary-700 mb-1">
                    Message
                  </label>
                  <textarea
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    placeholder="Your message..."
                    rows={5}
                    className="block w-full rounded-lg border border-primary-300 px-4 py-2.5 text-primary-900 placeholder-primary-400 focus:outline-none focus:ring-2 focus:ring-gold-500 focus:border-transparent"
                    required
                  />
                </div>

                {submitSuccess && (
                  <div className="bg-success-50 text-success-600 px-4 py-2 rounded-lg">
                    Message sent successfully! We'll get back to you soon.
                  </div>
                )}

                <Button
                  type="submit"
                  isLoading={isSubmitting}
                  className="w-full bg-gold-500 text-white hover:bg-gold-400"
                >
                  Send Message
                  <Send size={18} className="ml-2" />
                </Button>
              </form>
            </motion.div>
          </div>
        </div>
      </div>
    </Layout>
  );
}