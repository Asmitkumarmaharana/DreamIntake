import React, { forwardRef } from 'react';

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  helperText?: string;
  fullWidth?: boolean;
  className?: string;
}

const Input = forwardRef<HTMLInputElement, InputProps>(({
  label,
  error,
  helperText,
  fullWidth = false,
  className = '',
  ...props
}, ref) => {
  const widthClass = fullWidth ? 'w-full' : '';
  const errorClass = error ? 'border-error-500 focus:ring-error-500' : 'border-primary-300 focus:ring-gold-500';
  
  return (
    <div className={`${widthClass} ${className}`}>
      {label && (
        <label className="block text-sm font-medium text-primary-700 mb-1">
          {label}
        </label>
      )}
      <input
        ref={ref}
        className={`
          block ${widthClass} rounded-lg border ${errorClass}
          px-4 py-2.5 text-primary-900 placeholder-primary-400
          focus:outline-none focus:ring-2 focus:ring-opacity-50
          transition duration-150 ease-in-out
        `}
        {...props}
      />
      {error && (
        <p className="mt-1 text-sm text-error-500">{error}</p>
      )}
      {helperText && !error && (
        <p className="mt-1 text-sm text-primary-500">{helperText}</p>
      )}
    </div>
  );
});

Input.displayName = 'Input';
export default Input;