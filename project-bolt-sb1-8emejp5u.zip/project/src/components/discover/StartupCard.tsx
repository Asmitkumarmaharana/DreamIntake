import React from 'react';
import { motion } from 'framer-motion';
import { Heart, Eye, TrendingUp, ArrowUpRight } from 'lucide-react';
import Card from '../ui/Card';
import Button from '../ui/Button';
import { Startup } from '../../types';

interface StartupCardProps {
  startup: Startup;
  onClick: () => void;
}

export default function StartupCard({ startup, onClick }: StartupCardProps) {
  const { likes = 0, views = 0, isBoosted = false } = startup;
  
  const handleLike = (e: React.MouseEvent) => {
    e.stopPropagation();
    // Handle like functionality
  };

  // Get first letter of startup name if founder name is not available
  const avatarLetter = startup.founderName?.charAt(0) || startup.startupName.charAt(0) || '?';
  
  return (
    <Card 
      floating 
      className="h-full flex flex-col cursor-pointer transition-all duration-300"
      onClick={onClick}
    >
      {isBoosted && (
        <div className="absolute -top-3 -right-3 bg-gold-500 text-white text-xs font-bold px-3 py-1 rounded-full flex items-center">
          <TrendingUp size={12} className="mr-1" />
          TRENDING
        </div>
      )}
      
      <div className="p-6">
        <h3 className="text-xl font-bold text-primary-900 mb-2">{startup.startupName}</h3>
        
        <div className="flex items-center mb-4">
          <div className="h-8 w-8 rounded-full bg-primary-200 flex items-center justify-center text-primary-800 font-medium mr-2">
            {avatarLetter}
          </div>
          {startup.founderName && (
            <>
              <span className="text-sm font-medium text-primary-700">{startup.founderName}</span>
              <span className="mx-2 text-primary-400">•</span>
            </>
          )}
          <span className="text-sm text-primary-500">{startup.location}</span>
        </div>
        
        <p className="text-primary-600 mb-4 flex-grow">{startup.shortPitch}</p>
        
        <div className="flex flex-wrap gap-2 mb-4">
          {startup.industries.map((industry, index) => (
            <span 
              key={index} 
              className="text-xs bg-primary-100 text-primary-700 px-2 py-1 rounded-full"
            >
              {industry}
            </span>
          ))}
        </div>
      </div>
      
      <div className="border-t border-primary-100 p-4 flex items-center justify-between mt-auto">
        <div className="flex items-center space-x-4">
          <motion.button 
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={handleLike}
            className="flex items-center text-primary-500 hover:text-error-500 transition-colors"
          >
            <Heart size={18} className="mr-1" />
            <span>{likes}</span>
          </motion.button>
          
          <div className="flex items-center text-primary-500">
            <Eye size={18} className="mr-1" />
            <span>{views}</span>
          </div>
        </div>
        
        <Button size="sm" onClick={onClick}>
          View Details
          <ArrowUpRight size={14} className="ml-1" />
        </Button>
      </div>
    </Card>
  );
}