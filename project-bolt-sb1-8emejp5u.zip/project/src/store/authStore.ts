import { create } from 'zustand';
import { User } from '../types';

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  signupFounder: (name: string, email: string, startupName: string, startupIdea: string) => Promise<void>;
  signupInvestor: (name: string, email: string, industries: string[], location: string) => Promise<void>;
}

export const useAuthStore = create<AuthState>((set) => ({
  user: {
    id: 'f1',
    name: 'Arjun Patel',
    email: 'arjun@ecoharvest.com',
    userType: 'founder',
    createdAt: new Date().toISOString()
  },
  isAuthenticated: true,
  isLoading: false,
  error: null,
  
  login: async (email, password) => {
    set({ isLoading: true, error: null });
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // For demo, just check if it's a mock email
      if (email === 'founder@example.com') {
        set({ 
          user: { 
            id: 'f1',
            name: 'Demo Founder',
            email,
            userType: 'founder',
            createdAt: new Date().toISOString()
          },
          isAuthenticated: true,
          isLoading: false
        });
      } else if (email === 'investor@example.com') {
        set({ 
          user: { 
            id: 'i1',
            name: 'Demo Investor',
            email,
            userType: 'investor',
            createdAt: new Date().toISOString()
          },
          isAuthenticated: true,
          isLoading: false
        });
      } else {
        set({ error: 'Invalid credentials', isLoading: false });
      }
    } catch (error) {
      set({ error: 'Failed to login. Please try again.', isLoading: false });
    }
  },
  
  logout: () => {
    set({ user: null, isAuthenticated: false });
  },
  
  signupFounder: async (name, email, startupName, startupIdea) => {
    set({ isLoading: true, error: null });
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      set({ 
        user: { 
          id: `f${Date.now()}`,
          name,
          email,
          userType: 'founder',
          createdAt: new Date().toISOString()
        },
        isAuthenticated: true,
        isLoading: false
      });
    } catch (error) {
      set({ error: 'Failed to signup. Please try again.', isLoading: false });
    }
  },
  
  signupInvestor: async (name, email, industries, location) => {
    set({ isLoading: true, error: null });
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      set({ 
        user: { 
          id: `i${Date.now()}`,
          name,
          email,
          userType: 'investor',
          createdAt: new Date().toISOString()
        },
        isAuthenticated: true,
        isLoading: false
      });
    } catch (error) {
      set({ error: 'Failed to signup. Please try again.', isLoading: false });
    }
  },
}));