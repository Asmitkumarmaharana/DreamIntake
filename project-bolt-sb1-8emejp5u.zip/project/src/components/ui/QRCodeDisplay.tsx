import React, { useState } from 'react';
import Card from './Card';
import { Upload, Check, AlertCircle } from 'lucide-react';
import Button from './Button';

interface QRCodeDisplayProps {
  amount: number;
  description: string;
  onVerificationComplete?: () => void;
}

export default function QRCodeDisplay({ amount, description, onVerificationComplete }: QRCodeDisplayProps) {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [isVerifying, setIsVerifying] = useState(false);
  const [verificationError, setVerificationError] = useState<string | null>(null);

  const handleCopyUPI = () => {
    navigator.clipboard.writeText('asmitkumarmoharana875@okicici');
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) { // 5MB limit
        setVerificationError('Image size should be less than 5MB');
        return;
      }
      
      setSelectedFile(file);
      const url = URL.createObjectURL(file);
      setPreviewUrl(url);
      setVerificationError(null);
    }
  };

  const handleVerification = async () => {
    if (!selectedFile) return;
    
    setIsVerifying(true);
    setVerificationError(null);

    try {
      // Simulate verification delay
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // In production, you would:
      // 1. Upload the screenshot to your server
      // 2. Verify the payment details
      // 3. Update the database
      
      if (onVerificationComplete) {
        onVerificationComplete();
      }
    } catch (error) {
      setVerificationError('Verification failed. Please try again.');
    } finally {
      setIsVerifying(false);
    }
  };

  return (
    <Card className="max-w-sm mx-auto text-center">
      <h3 className="text-xl font-semibold text-primary-900 mb-3">Pay ₹{amount}</h3>
      <p className="text-primary-600 mb-6">{description}</p>
      
      <div className="bg-primary-900 p-6 rounded-lg mb-6">
        <div className="flex flex-col items-center space-y-4">
          <p className="text-white text-lg font-medium">Pay using UPI</p>
          <div className="bg-white px-4 py-3 rounded-lg w-full">
            <p className="text-primary-900 font-medium mb-2">asmitkumarmoharana875@okicici</p>
            <button 
              onClick={handleCopyUPI}
              className="text-gold-500 hover:text-gold-600 text-sm font-medium"
            >
              Copy UPI ID
            </button>
          </div>
        </div>
      </div>
      
      <div className="mt-4 pt-4 border-t border-primary-200">
        <div className="flex justify-between text-sm mb-4">
          <span className="text-primary-600">Amount:</span>
          <span className="font-medium text-primary-900">₹{amount}</span>
        </div>
        <div className="flex justify-between text-sm">
          <span className="text-primary-600">Payment Method:</span>
          <span className="font-medium text-primary-900">UPI</span>
        </div>
      </div>

      <div className="mt-6 pt-6 border-t border-primary-200">
        <div className="mb-4">
          <p className="text-primary-900 font-medium mb-2">Upload Payment Screenshot</p>
          <p className="text-sm text-primary-600">
            Please upload a screenshot of your payment confirmation
          </p>
        </div>

        <div className="border-2 border-dashed border-primary-200 rounded-lg p-4">
          {previewUrl ? (
            <div className="space-y-4">
              <img 
                src={previewUrl} 
                alt="Payment screenshot" 
                className="max-h-48 mx-auto rounded-lg"
              />
              <Button
                onClick={() => {
                  setSelectedFile(null);
                  setPreviewUrl(null);
                }}
                variant="outline"
                className="text-error-600 border-error-600 hover:bg-error-50"
              >
                Remove
              </Button>
            </div>
          ) : (
            <label className="cursor-pointer block">
              <input
                type="file"
                accept="image/*"
                onChange={handleFileSelect}
                className="hidden"
              />
              <div className="flex flex-col items-center py-4">
                <Upload className="w-8 h-8 text-primary-400 mb-2" />
                <p className="text-primary-900 font-medium">Click to upload screenshot</p>
                <p className="text-sm text-primary-500">PNG, JPG up to 5MB</p>
              </div>
            </label>
          )}
        </div>

        {verificationError && (
          <div className="mt-4 p-3 bg-error-50 text-error-600 rounded-lg flex items-center">
            <AlertCircle size={16} className="mr-2" />
            {verificationError}
          </div>
        )}

        <Button
          onClick={handleVerification}
          disabled={!selectedFile || isVerifying}
          isLoading={isVerifying}
          className="mt-4 w-full"
        >
          {isVerifying ? 'Verifying...' : 'Verify Payment'}
        </Button>
      </div>
    </Card>
  );
}