import React from 'react';
import { motion } from 'framer-motion';
import Layout from '../components/layout/Layout';

export default function Terms() {
  React.useEffect(() => {
    document.title = 'Terms of Service | Dream Intake';
  }, []);

  return (
    <Layout>
      <div className="pt-20 pb-20 bg-primary-50 min-h-screen">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center mb-12"
          >
            <h1 className="text-4xl sm:text-5xl font-serif font-bold text-primary-900 mb-4">
              Terms of <span className="text-gold-500">Service</span>
            </h1>
            <p className="text-xl text-primary-600 max-w-3xl mx-auto">
              Please read these terms carefully before using our platform
            </p>
          </motion.div>

          <div className="max-w-4xl mx-auto bg-white rounded-lg shadow-md p-8">
            <div className="prose max-w-none">
              <section className="mb-8">
                <h2 className="text-2xl font-bold text-primary-900 mb-4">1. Acceptance of Terms</h2>
                <p className="text-primary-600 mb-4">
                  By accessing and using Dream Intake ("the Platform"), you agree to be bound by these Terms of Service. If you do not agree to these terms, please do not use our platform.
                </p>
              </section>

              <section className="mb-8">
                <h2 className="text-2xl font-bold text-primary-900 mb-4">2. User Registration</h2>
                <p className="text-primary-600 mb-4">
                  To use certain features of the Platform, you must register for an account. You agree to:
                </p>
                <ul className="list-disc pl-6 text-primary-600 mb-4">
                  <li>Provide accurate and complete information</li>
                  <li>Maintain the security of your account</li>
                  <li>Accept responsibility for all activities under your account</li>
                  <li>Pay the applicable registration fees</li>
                </ul>
              </section>

              <section className="mb-8">
                <h2 className="text-2xl font-bold text-primary-900 mb-4">3. Platform Rules</h2>
                <p className="text-primary-600 mb-4">Users must not:</p>
                <ul className="list-disc pl-6 text-primary-600 mb-4">
                  <li>Submit false or misleading information</li>
                  <li>Violate any applicable laws or regulations</li>
                  <li>Infringe on intellectual property rights</li>
                  <li>Harass or discriminate against other users</li>
                  <li>Attempt to circumvent platform security</li>
                </ul>
              </section>

              <section className="mb-8">
                <h2 className="text-2xl font-bold text-primary-900 mb-4">4. Fees and Payments</h2>
                <p className="text-primary-600 mb-4">
                  The following fees apply to platform usage:
                </p>
                <ul className="list-disc pl-6 text-primary-600 mb-4">
                  <li>Founder registration: ₹1</li>
                  <li>Investor registration: ₹99</li>
                  <li>Startup boost feature: ₹300 per 7 days</li>
                </ul>
                <p className="text-primary-600">All fees are non-refundable unless required by law.</p>
              </section>

              <section className="mb-8">
                <h2 className="text-2xl font-bold text-primary-900 mb-4">5. Intellectual Property</h2>
                <p className="text-primary-600 mb-4">
                  Users retain ownership of their content but grant Dream Intake a license to use, display, and distribute content on the platform. The platform's branding, design, and features remain the property of Dream Intake.
                </p>
              </section>

              <section className="mb-8">
                <h2 className="text-2xl font-bold text-primary-900 mb-4">6. Privacy and Data Protection</h2>
                <p className="text-primary-600 mb-4">
                  Our collection and use of personal information is governed by our Privacy Policy. By using the Platform, you consent to our data practices as described in the Privacy Policy.
                </p>
              </section>

              <section className="mb-8">
                <h2 className="text-2xl font-bold text-primary-900 mb-4">7. Limitation of Liability</h2>
                <p className="text-primary-600 mb-4">
                  Dream Intake is not liable for:
                </p>
                <ul className="list-disc pl-6 text-primary-600 mb-4">
                  <li>Investment decisions made through the platform</li>
                  <li>Disputes between users</li>
                  <li>Content accuracy or completeness</li>
                  <li>Service interruptions or technical issues</li>
                </ul>
              </section>

              <section className="mb-8">
                <h2 className="text-2xl font-bold text-primary-900 mb-4">8. Termination</h2>
                <p className="text-primary-600 mb-4">
                  We reserve the right to suspend or terminate accounts that violate these terms or engage in harmful behavior. Users may terminate their accounts at any time.
                </p>
              </section>

              <section className="mb-8">
                <h2 className="text-2xl font-bold text-primary-900 mb-4">9. Changes to Terms</h2>
                <p className="text-primary-600 mb-4">
                  We may modify these terms at any time. Continued use of the Platform after changes constitutes acceptance of the modified terms.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-primary-900 mb-4">10. Contact Information</h2>
                <p className="text-primary-600 mb-4">
                  For questions about these terms, please contact us at:
                </p>
                <div className="bg-primary-50 p-4 rounded-lg">
                  <p className="text-primary-700">Email: legal@dreamintake.app</p>
                  <p className="text-primary-700">Address: 123 Startup Street, Bangalore, India</p>
                </div>
                <p className="text-primary-500 mt-4 text-sm">
                  Last Updated: February 20, 2024
                </p>
              </section>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}