import React from 'react';
import { motion } from 'framer-motion';
import Layout from '../components/layout/Layout';
import { Shield, Target, Users, AlertTriangle, CheckCircle, XCircle } from 'lucide-react';

export default function InvestorGuidelines() {
  React.useEffect(() => {
    document.title = 'Investor Guidelines | Dream Intake';
  }, []);

  return (
    <Layout>
      <div className="pt-20 pb-20 bg-primary-50 min-h-screen">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center mb-12"
          >
            <h1 className="text-4xl sm:text-5xl font-serif font-bold text-primary-900 mb-4">
              Investor <span className="text-gold-500">Guidelines</span>
            </h1>
            <p className="text-xl text-primary-600 max-w-3xl mx-auto">
              Essential information and best practices for investing in startups through Dream Intake
            </p>
          </motion.div>

          <div className="max-w-4xl mx-auto space-y-8">
            {/* Investment Process */}
            <motion.section
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="bg-white rounded-lg shadow-md p-8"
            >
              <div className="flex items-center mb-6">
                <Target className="w-8 h-8 text-gold-500 mr-3" />
                <h2 className="text-2xl font-bold text-primary-900">Investment Process</h2>
              </div>
              <div className="space-y-4">
                <div className="flex items-start">
                  <div className="w-8 h-8 bg-primary-100 rounded-full flex items-center justify-center mr-4 flex-shrink-0">
                    <span className="font-semibold text-primary-700">1</span>
                  </div>
                  <div>
                    <h3 className="font-semibold text-primary-900 mb-1">Discovery</h3>
                    <p className="text-primary-600">Browse through our curated list of startups and use filters to find opportunities that match your investment criteria.</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="w-8 h-8 bg-primary-100 rounded-full flex items-center justify-center mr-4 flex-shrink-0">
                    <span className="font-semibold text-primary-700">2</span>
                  </div>
                  <div>
                    <h3 className="font-semibold text-primary-900 mb-1">Due Diligence</h3>
                    <p className="text-primary-600">Review startup profiles, pitch decks, and financial information. Request additional documents if needed.</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="w-8 h-8 bg-primary-100 rounded-full flex items-center justify-center mr-4 flex-shrink-0">
                    <span className="font-semibold text-primary-700">3</span>
                  </div>
                  <div>
                    <h3 className="font-semibold text-primary-900 mb-1">Communication</h3>
                    <p className="text-primary-600">Connect with founders through our messaging system to discuss opportunities and arrange meetings.</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="w-8 h-8 bg-primary-100 rounded-full flex items-center justify-center mr-4 flex-shrink-0">
                    <span className="font-semibold text-primary-700">4</span>
                  </div>
                  <div>
                    <h3 className="font-semibold text-primary-900 mb-1">Investment</h3>
                    <p className="text-primary-600">Finalize investment terms and complete the transaction offline through proper legal channels.</p>
                  </div>
                </div>
              </div>
            </motion.section>

            {/* Investment Criteria */}
            <motion.section
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="bg-white rounded-lg shadow-md p-8"
            >
              <div className="flex items-center mb-6">
                <Shield className="w-8 h-8 text-gold-500 mr-3" />
                <h2 className="text-2xl font-bold text-primary-900">Investment Criteria</h2>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-3">
                  <h3 className="font-semibold text-primary-900 flex items-center">
                    <CheckCircle className="w-5 h-5 text-success-500 mr-2" />
                    What We Look For
                  </h3>
                  <ul className="space-y-2 text-primary-600">
                    <li>• Strong founding team with relevant experience</li>
                    <li>• Clear market opportunity and growth potential</li>
                    <li>• Innovative solution to real problems</li>
                    <li>• Scalable business model</li>
                    <li>• Clear competitive advantage</li>
                  </ul>
                </div>
                <div className="space-y-3">
                  <h3 className="font-semibold text-primary-900 flex items-center">
                    <XCircle className="w-5 h-5 text-error-500 mr-2" />
                    What We Avoid
                  </h3>
                  <ul className="space-y-2 text-primary-600">
                    <li>• Unregistered businesses</li>
                    <li>• Unclear business models</li>
                    <li>• Incomplete documentation</li>
                    <li>• High-risk sectors</li>
                    <li>• Non-compliant operations</li>
                  </ul>
                </div>
              </div>
            </motion.section>

            {/* Best Practices */}
            <motion.section
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="bg-white rounded-lg shadow-md p-8"
            >
              <div className="flex items-center mb-6">
                <Users className="w-8 h-8 text-gold-500 mr-3" />
                <h2 className="text-2xl font-bold text-primary-900">Best Practices</h2>
              </div>
              <div className="space-y-4">
                <div className="bg-primary-50 p-4 rounded-lg">
                  <h3 className="font-semibold text-primary-900 mb-2">Due Diligence Checklist</h3>
                  <ul className="space-y-2 text-primary-600">
                    <li>✓ Review business registration documents</li>
                    <li>✓ Analyze financial statements and projections</li>
                    <li>✓ Evaluate market size and competition</li>
                    <li>✓ Check founder background and experience</li>
                    <li>✓ Assess intellectual property rights</li>
                  </ul>
                </div>
                <div className="bg-primary-50 p-4 rounded-lg">
                  <h3 className="font-semibold text-primary-900 mb-2">Communication Guidelines</h3>
                  <ul className="space-y-2 text-primary-600">
                    <li>✓ Maintain professional communication</li>
                    <li>✓ Respond to messages promptly</li>
                    <li>✓ Keep all discussions confidential</li>
                    <li>✓ Document all agreements in writing</li>
                    <li>✓ Use platform messaging for initial contact</li>
                  </ul>
                </div>
              </div>
            </motion.section>

            {/* Risk Warning */}
            <motion.section
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
              className="bg-error-50 rounded-lg p-8"
            >
              <div className="flex items-start">
                <AlertTriangle className="w-8 h-8 text-error-500 mr-4 flex-shrink-0" />
                <div>
                  <h2 className="text-xl font-bold text-error-700 mb-2">Risk Warning</h2>
                  <p className="text-error-600">
                    Investing in startups involves significant risks, including illiquidity and potential loss of investment. Always conduct thorough due diligence and consider seeking professional financial advice before making investment decisions. Dream Intake does not provide investment advice or guarantee returns.
                  </p>
                </div>
              </div>
            </motion.section>
          </div>
        </div>
      </div>
    </Layout>
  );
}