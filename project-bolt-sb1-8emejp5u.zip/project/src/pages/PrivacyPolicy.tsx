import React from 'react';
import { motion } from 'framer-motion';
import Layout from '../components/layout/Layout';

export default function PrivacyPolicy() {
  React.useEffect(() => {
    document.title = 'Privacy Policy | Dream Intake';
  }, []);

  return (
    <Layout>
      <div className="pt-20 pb-20 bg-primary-50 min-h-screen">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center mb-12"
          >
            <h1 className="text-4xl sm:text-5xl font-serif font-bold text-primary-900 mb-4">
              Privacy <span className="text-gold-500">Policy</span>
            </h1>
            <p className="text-xl text-primary-600 max-w-3xl mx-auto">
              How we handle and protect your information
            </p>
          </motion.div>

          <div className="max-w-4xl mx-auto bg-white rounded-lg shadow-md p-8">
            <div className="prose max-w-none">
              <section className="mb-8">
                <h2 className="text-2xl font-bold text-primary-900 mb-4">Introduction</h2>
                <p className="text-primary-600 mb-4">
                  Dream Intake ("we," "our," or "us") is committed to protecting your privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you use our platform.
                </p>
              </section>

              <section className="mb-8">
                <h2 className="text-2xl font-bold text-primary-900 mb-4">Information We Collect</h2>
                <h3 className="text-xl font-semibold text-primary-800 mb-3">Personal Information</h3>
                <ul className="list-disc pl-6 text-primary-600 mb-4">
                  <li>Name and contact information</li>
                  <li>Login credentials</li>
                  <li>Profile information</li>
                  <li>Payment information</li>
                  <li>Communication preferences</li>
                </ul>

                <h3 className="text-xl font-semibold text-primary-800 mb-3">Startup Information</h3>
                <ul className="list-disc pl-6 text-primary-600 mb-4">
                  <li>Company details</li>
                  <li>Business plans</li>
                  <li>Pitch materials</li>
                  <li>Financial information</li>
                </ul>
              </section>

              <section className="mb-8">
                <h2 className="text-2xl font-bold text-primary-900 mb-4">How We Use Your Information</h2>
                <ul className="list-disc pl-6 text-primary-600 mb-4">
                  <li>To provide and maintain our platform</li>
                  <li>To process your transactions</li>
                  <li>To communicate with you</li>
                  <li>To improve our services</li>
                  <li>To comply with legal obligations</li>
                </ul>
              </section>

              <section className="mb-8">
                <h2 className="text-2xl font-bold text-primary-900 mb-4">Information Sharing</h2>
                <p className="text-primary-600 mb-4">
                  We may share your information with:
                </p>
                <ul className="list-disc pl-6 text-primary-600 mb-4">
                  <li>Other platform users (as per your settings)</li>
                  <li>Service providers</li>
                  <li>Legal authorities when required</li>
                </ul>
              </section>

              <section className="mb-8">
                <h2 className="text-2xl font-bold text-primary-900 mb-4">Data Security</h2>
                <p className="text-primary-600 mb-4">
                  We implement appropriate security measures to protect your information, including:
                </p>
                <ul className="list-disc pl-6 text-primary-600 mb-4">
                  <li>Encryption of sensitive data</li>
                  <li>Regular security assessments</li>
                  <li>Access controls</li>
                  <li>Secure data storage</li>
                </ul>
              </section>

              <section className="mb-8">
                <h2 className="text-2xl font-bold text-primary-900 mb-4">Your Rights</h2>
                <p className="text-primary-600 mb-4">
                  You have the right to:
                </p>
                <ul className="list-disc pl-6 text-primary-600 mb-4">
                  <li>Access your personal information</li>
                  <li>Correct inaccurate information</li>
                  <li>Request deletion of your information</li>
                  <li>Opt-out of marketing communications</li>
                </ul>
              </section>

              <section className="mb-8">
                <h2 className="text-2xl font-bold text-primary-900 mb-4">Contact Us</h2>
                <p className="text-primary-600 mb-4">
                  If you have questions about this Privacy Policy, please contact us at:
                </p>
                <div className="bg-primary-50 p-4 rounded-lg">
                  <p className="text-primary-700">Email: privacy@dreamintake.app</p>
                  <p className="text-primary-700">Address: 123 Startup Street, Bangalore, India</p>
                </div>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-primary-900 mb-4">Updates to This Policy</h2>
                <p className="text-primary-600">
                  We may update this Privacy Policy from time to time. The updated version will be indicated by an updated "Last Updated" date and the updated version will be effective as soon as it is accessible.
                </p>
                <p className="text-primary-500 mt-4 text-sm">
                  Last Updated: February 20, 2024
                </p>
              </section>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}