import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import Layout from '../components/layout/Layout';
import Button from '../components/ui/Button';
import Input from '../components/ui/Input';
import { useAuthStore } from '../store/authStore';

export default function Login() {
  const navigate = useNavigate();
  const { login, isLoading, error } = useAuthStore();
  
  const [formData, setFormData] = useState({
    email: '',
    password: '',
  });
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      await login(formData.email, formData.password);
      navigate('/discover');
    } catch (error) {
      console.error('Login failed:', error);
    }
  };
  
  return (
    <Layout noFooter>
      <div className="min-h-screen bg-primary-50 pt-20 pb-12 flex flex-col items-center justify-center">
        <div className="w-full max-w-md">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="bg-white p-8 rounded-lg shadow-card"
          >
            <div className="text-center mb-8">
              <img 
                src="https://assets.bolt.new/d7e65b96-ae90-4de4-8e71-5ab2dfd8c173" 
                alt="Dream Intake" 
                className="h-12 mx-auto mb-6" 
              />
              <h1 className="text-2xl font-bold text-primary-900">Sign In</h1>
              <p className="text-primary-600 mt-2">
                Welcome back to Dream Intake
              </p>
            </div>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <Input
                label="Email Address"
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                placeholder="you@example.com"
                required
                fullWidth
              />
              
              <Input
                label="Password"
                type="password"
                name="password"
                value={formData.password}
                onChange={handleChange}
                placeholder="Enter your password"
                required
                fullWidth
              />
              
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <input
                    id="remember-me"
                    name="remember-me"
                    type="checkbox"
                    className="h-4 w-4 text-gold-500 focus:ring-gold-500 border-primary-300 rounded"
                  />
                  <label htmlFor="remember-me" className="ml-2 block text-sm text-primary-700">
                    Remember me
                  </label>
                </div>
                
                <a href="#" className="text-sm font-medium text-gold-500 hover:text-gold-600">
                  Forgot password?
                </a>
              </div>
              
              {error && (
                <p className="text-error-500 text-sm">{error}</p>
              )}
              
              <Button
                type="submit"
                fullWidth
                isLoading={isLoading}
              >
                Sign In
              </Button>
            </form>
            
            <div className="mt-6 text-center">
              <p className="text-sm text-primary-600">
                Don't have an account?{' '}
                <Link to="/signup" className="font-medium text-gold-500 hover:text-gold-600">
                  Sign up
                </Link>
              </p>
            </div>
            
            <div className="mt-8 text-center text-xs text-primary-500">
              By continuing, you agree to Dream Intake's{' '}
              <a href="#" className="text-gold-500 hover:text-gold-600">Terms of Service</a> and{' '}
              <a href="#" className="text-gold-500 hover:text-gold-600">Privacy Policy</a>.
            </div>
          </motion.div>
        </div>
      </div>
    </Layout>
  );
}