import React, { useState } from 'react';
import { X, Search, Filter, MapPin, Briefcase } from 'lucide-react';
import { INDUSTRIES, LOCATIONS } from '../../utils/mockData';
import { useStartupStore } from '../../store/startupStore';
import Button from '../ui/Button';

export default function FilterBar() {
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const { filters, setFilters } = useStartupStore();
  
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFilters({ searchQuery: e.target.value });
  };
  
  const toggleIndustry = (industry: string) => {
    const currentIndustries = filters.industries;
    const updatedIndustries = currentIndustries.includes(industry)
      ? currentIndustries.filter(i => i !== industry)
      : [...currentIndustries, industry];
    
    setFilters({ industries: updatedIndustries });
  };
  
  const toggleLocation = (location: string) => {
    const currentLocations = filters.locations;
    const updatedLocations = currentLocations.includes(location)
      ? currentLocations.filter(l => l !== location)
      : [...currentLocations, location];
    
    setFilters({ locations: updatedLocations });
  };
  
  const clearFilters = () => {
    setFilters({
      industries: [],
      locations: [],
      searchQuery: '',
    });
  };
  
  const totalFiltersApplied = 
    filters.industries.length + 
    filters.locations.length +
    (filters.searchQuery ? 1 : 0);
  
  return (
    <div className="bg-white shadow-md rounded-lg p-6 mb-8">
      <div className="flex flex-col md:flex-row md:items-center gap-4">
        <div className="relative flex-grow">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search size={18} className="text-primary-400" />
          </div>
          <input
            type="text"
            placeholder="Search startups by name or description..."
            value={filters.searchQuery}
            onChange={handleSearchChange}
            className="block w-full pl-10 pr-3 py-2.5 border border-primary-300 rounded-lg focus:ring-2 focus:ring-gold-500 focus:border-transparent text-primary-900 placeholder-primary-400"
          />
        </div>
        
        <div className="flex items-center gap-3">
          <Button 
            variant="outline" 
            onClick={() => setIsFilterOpen(!isFilterOpen)}
            className="flex items-center"
          >
            <Filter size={18} className="mr-2" />
            Advanced Filters
            {totalFiltersApplied > 0 && (
              <span className="ml-2 bg-gold-500 text-white text-xs rounded-full w-5 h-5 inline-flex items-center justify-center">
                {totalFiltersApplied}
              </span>
            )}
          </Button>
          
          {totalFiltersApplied > 0 && (
            <button 
              onClick={clearFilters}
              className="text-primary-600 hover:text-primary-900 text-sm font-medium"
            >
              Clear All
            </button>
          )}
        </div>
      </div>
      
      {isFilterOpen && (
        <div className="mt-6 pt-6 border-t border-primary-200">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Briefcase size={20} className="text-gold-500" />
                <h3 className="font-medium text-primary-900">Industries</h3>
              </div>
              <div className="flex flex-wrap gap-2 max-h-[320px] overflow-y-auto pr-2">
                {INDUSTRIES.map(industry => (
                  <button
                    key={industry}
                    onClick={() => toggleIndustry(industry)}
                    className={`
                      text-sm px-3 py-1.5 rounded-full border transition-all
                      ${filters.industries.includes(industry) 
                        ? 'bg-gold-500 text-white border-gold-500 shadow-sm' 
                        : 'bg-white text-primary-700 border-primary-300 hover:bg-primary-50 hover:border-primary-400'}
                    `}
                  >
                    {industry}
                  </button>
                ))}
              </div>
            </div>
            
            <div>
              <div className="flex items-center gap-2 mb-4">
                <MapPin size={20} className="text-gold-500" />
                <h3 className="font-medium text-primary-900">Locations</h3>
              </div>
              <div className="flex flex-wrap gap-2 max-h-[320px] overflow-y-auto pr-2">
                {LOCATIONS.map(location => (
                  <button
                    key={location}
                    onClick={() => toggleLocation(location)}
                    className={`
                      text-sm px-3 py-1.5 rounded-full border transition-all
                      ${filters.locations.includes(location) 
                        ? 'bg-gold-500 text-white border-gold-500 shadow-sm' 
                        : 'bg-white text-primary-700 border-primary-300 hover:bg-primary-50 hover:border-primary-400'}
                    `}
                  >
                    {location}
                  </button>
                ))}
              </div>
            </div>
          </div>
          
          <div className="flex justify-end mt-6">
            <button 
              onClick={() => setIsFilterOpen(false)}
              className="flex items-center text-primary-600 hover:text-primary-900 text-sm font-medium"
            >
              <X size={16} className="mr-1" />
              Close Filters
            </button>
          </div>
        </div>
      )}
    </div>
  );
}