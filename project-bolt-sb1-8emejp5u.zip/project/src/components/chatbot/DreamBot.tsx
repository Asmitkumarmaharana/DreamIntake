import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MessageSquare, X, Send, Bot, User, AlertCircle } from 'lucide-react';

// Predefined responses for common questions
const PREDEFINED_RESPONSES = {
  registration: {
    keywords: ['register', 'sign up', 'signup', 'join', 'create account', 'registration'],
    response: "To register on Dream Intake:\n\n• Founders: Pay ₹1 registration fee\n• Investors: Pay ₹99 registration fee\n\nClick the 'Sign Up' button in the top right to get started! 🚀"
  },
  payment: {
    keywords: ['payment', 'pay', 'fee', 'cost', 'pricing', 'charges', 'upi'],
    response: "We accept payments via UPI:\n\n• Founder registration: ₹1\n• Investor registration: ₹99\n• Startup boost: ₹300 for 7 days\n\nAll payments are secure and processed instantly! 💳"
  },
  pitch: {
    keywords: ['pitch', 'startup idea', 'submit', 'proposal', 'present'],
    response: "To pitch your startup:\n\n1. Register as a founder\n2. Create your startup profile\n3. Upload a 1-2 minute pitch video\n4. Add company details\n\nNeed to pitch another startup? Use the 'Pitch Another Startup' button in your profile! 🎯"
  },
  boost: {
    keywords: ['boost', 'promote', 'trending', 'visibility', 'feature'],
    response: "Boost your startup for ₹300 and get:\n\n• 7 days in the trending section\n• Higher visibility to investors\n• Priority in search results\n• Featured status on homepage\n\nBoost from your startup dashboard! 🚀"
  },
  investors: {
    keywords: ['investor', 'funding', 'invest', 'money', 'capital'],
    response: "Connect with investors by:\n\n• Creating a compelling profile\n• Adding a clear pitch video\n• Using the boost feature\n• Responding promptly to messages\n\nOver 200+ active investors are waiting to discover your startup! 💼"
  }
};

const INITIAL_MESSAGE = {
  id: 'welcome',
  sender: 'bot',
  content: "👋 Hi! I'm DreamBot, your AI assistant for Dream Intake. I can help you with:\n\n• Finding investors\n• Preparing pitch decks\n• Platform navigation\n• Registration process\n• Startup boost features\n\nHow can I assist you today?"
};

const FALLBACK_RESPONSE = "I'm still learning how to answer that. Please reach out to support or try asking something else. 🙏";

export default function DreamBot() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState([INITIAL_MESSAGE]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  useEffect(() => {
    if (isOpen && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isOpen]);

  const findPredefinedResponse = (input: string) => {
    const lowercaseInput = input.toLowerCase();
    
    for (const [key, data] of Object.entries(PREDEFINED_RESPONSES)) {
      if (data.keywords.some(keyword => lowercaseInput.includes(keyword))) {
        return data.response;
      }
    }
    
    return FALLBACK_RESPONSE;
  };

  const handleSendMessage = async () => {
    if (input.trim() === '') return;
    
    const userMessage = { id: Date.now().toString(), sender: 'user', content: input };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);
    
    // Simulate typing delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const response = findPredefinedResponse(input);
    const botMessage = { 
      id: (Date.now() + 1).toString(), 
      sender: 'bot', 
      content: response
    };
    
    setMessages(prev => [...prev, botMessage]);
    setIsTyping(false);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };
  
  return (
    <div className="fixed bottom-4 right-4 z-50">
      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => setIsOpen(true)}
        className={`
          flex items-center justify-center w-14 h-14 rounded-full 
          bg-gold-500 text-white shadow-lg hover:bg-gold-400 
          transition-colors duration-200 focus:outline-none
          ${isOpen ? 'hidden' : ''}
        `}
      >
        <MessageSquare size={24} />
      </motion.button>
      
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            transition={{ duration: 0.2 }}
            className="bg-white rounded-lg shadow-xl w-[340px] sm:w-[400px] h-[600px] overflow-hidden flex flex-col"
          >
            <div className="bg-primary-900 text-white p-4 flex items-center justify-between">
              <div className="flex items-center">
                <div className="bg-gold-500 rounded-full w-10 h-10 flex items-center justify-center mr-3">
                  <Bot size={20} />
                </div>
                <div>
                  <h3 className="font-medium">DreamBot Assistant</h3>
                  <p className="text-xs text-primary-300">Always here to help</p>
                </div>
              </div>
              <button 
                onClick={() => setIsOpen(false)}
                className="text-primary-300 hover:text-white transition-colors p-1"
              >
                <X size={20} />
              </button>
            </div>
            
            <div className="flex-grow p-4 overflow-y-auto bg-primary-50/30">
              <div className="space-y-4">
                {messages.map(message => (
                  <motion.div
                    key={message.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div className="flex items-end max-w-[85%] gap-2">
                      {message.sender === 'bot' && (
                        <div className="w-6 h-6 rounded-full bg-gold-500 flex items-center justify-center flex-shrink-0">
                          <Bot size={14} className="text-white" />
                        </div>
                      )}
                      <div
                        className={`
                          rounded-2xl px-4 py-2 whitespace-pre-wrap
                          ${message.sender === 'user'
                            ? 'bg-gold-500 text-white rounded-br-none'
                            : 'bg-white shadow-sm text-primary-800 rounded-bl-none'}
                        `}
                      >
                        <p className="text-sm leading-relaxed">{message.content}</p>
                      </div>
                      {message.sender === 'user' && (
                        <div className="w-6 h-6 rounded-full bg-primary-200 flex items-center justify-center flex-shrink-0">
                          <User size={14} className="text-primary-600" />
                        </div>
                      )}
                    </div>
                  </motion.div>
                ))}
                {isTyping && (
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="flex justify-start"
                  >
                    <div className="flex items-end gap-2">
                      <div className="w-6 h-6 rounded-full bg-gold-500 flex items-center justify-center">
                        <Bot size={14} className="text-white" />
                      </div>
                      <div className="bg-white shadow-sm rounded-2xl rounded-bl-none px-4 py-2">
                        <div className="flex space-x-1">
                          <div className="w-2 h-2 bg-primary-300 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                          <div className="w-2 h-2 bg-primary-300 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                          <div className="w-2 h-2 bg-primary-300 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                )}
                <div ref={messagesEndRef} />
              </div>
            </div>
            
            <div className="p-4 bg-white border-t border-primary-100">
              <div className="flex items-end gap-2">
                <div className="flex-grow">
                  <textarea
                    ref={inputRef}
                    value={input}
                    onChange={e => setInput(e.target.value)}
                    onKeyDown={handleKeyPress}
                    placeholder="Type your message..."
                    rows={1}
                    className="w-full rounded-2xl border border-primary-200 px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-gold-500 focus:border-transparent resize-none"
                    style={{ minHeight: '40px', maxHeight: '120px' }}
                  />
                </div>
                <button
                  onClick={handleSendMessage}
                  disabled={isTyping || !input.trim()}
                  className={`
                    flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center
                    transition-colors duration-200
                    ${input.trim() && !isTyping
                      ? 'bg-gold-500 text-white hover:bg-gold-400'
                      : 'bg-primary-100 text-primary-400 cursor-not-allowed'}
                  `}
                >
                  <Send size={18} />
                </button>
              </div>
              <p className="mt-2 text-xs text-primary-400 text-center">
                Press Enter to send, Shift + Enter for new line
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}