export interface User {
  id: string;
  name: string;
  email: string;
  userType: 'founder' | 'investor';
  createdAt: string;
}

export interface Founder extends User {
  userType: 'founder';
  startupName: string;
  startupIdea: string;
  pitchVideoUrl?: string;
  isBoosted: boolean;
  boostExpiresAt?: string;
}

export interface Investor extends User {
  userType: 'investor';
  industries: string[];
  location: string;
}

export interface Startup {
  id: string;
  founderId: string;
  founderName: string;
  startupName: string;
  shortPitch: string;
  fullPitch: string;
  pitchVideoUrl?: string;
  industries: string[];
  location: string;
  createdAt: string;
  views: number;
  likes: number;
  isBoosted: boolean;
  boostExpiresAt?: string;
}

export interface Message {
  id: string;
  senderId: string;
  receiverId: string;
  content: string;
  timestamp: string;
  isRead: boolean;
}

export interface ChatThread {
  id: string;
  participants: string[];
  lastMessage?: Message;
  updatedAt: string;
}