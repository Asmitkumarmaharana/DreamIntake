import React from 'react';
import { motion } from 'framer-motion';
import Layout from '../components/layout/Layout';

export default function CookiePolicy() {
  React.useEffect(() => {
    document.title = 'Cookie Policy | Dream Intake';
  }, []);

  return (
    <Layout>
      <div className="pt-20 pb-20 bg-primary-50 min-h-screen">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center mb-12"
          >
            <h1 className="text-4xl sm:text-5xl font-serif font-bold text-primary-900 mb-4">
              Cookie <span className="text-gold-500">Policy</span>
            </h1>
            <p className="text-xl text-primary-600 max-w-3xl mx-auto">
              Understanding how we use cookies to improve your experience
            </p>
          </motion.div>

          <div className="max-w-4xl mx-auto bg-white rounded-lg shadow-md p-8">
            <div className="prose max-w-none">
              <section className="mb-8">
                <h2 className="text-2xl font-bold text-primary-900 mb-4">What Are Cookies?</h2>
                <p className="text-primary-600 mb-4">
                  Cookies are small text files that are placed on your device when you visit our website. They help us provide you with a better experience by remembering your preferences, analyzing site usage, and assisting with our marketing efforts.
                </p>
              </section>

              <section className="mb-8">
                <h2 className="text-2xl font-bold text-primary-900 mb-4">Types of Cookies We Use</h2>
                
                <h3 className="text-xl font-semibold text-primary-800 mb-3">Essential Cookies</h3>
                <p className="text-primary-600 mb-4">
                  These cookies are necessary for the website to function properly. They enable basic functions like page navigation and access to secure areas of the website.
                </p>

                <h3 className="text-xl font-semibold text-primary-800 mb-3">Performance Cookies</h3>
                <p className="text-primary-600 mb-4">
                  These cookies help us understand how visitors interact with our website by collecting and reporting information anonymously.
                </p>

                <h3 className="text-xl font-semibold text-primary-800 mb-3">Functionality Cookies</h3>
                <p className="text-primary-600 mb-4">
                  These cookies allow the website to remember choices you make and provide enhanced, more personal features.
                </p>

                <h3 className="text-xl font-semibold text-primary-800 mb-3">Marketing Cookies</h3>
                <p className="text-primary-600 mb-4">
                  These cookies track your online activity to help advertisers deliver more relevant advertising or to limit how many times you see an ad.
                </p>
              </section>

              <section className="mb-8">
                <h2 className="text-2xl font-bold text-primary-900 mb-4">How We Use Cookies</h2>
                <ul className="list-disc pl-6 text-primary-600 mb-4">
                  <li>To remember your preferences and settings</li>
                  <li>To improve site navigation and user experience</li>
                  <li>To analyze site usage and performance</li>
                  <li>To personalize content and advertisements</li>
                  <li>To provide secure login functionality</li>
                </ul>
              </section>

              <section className="mb-8">
                <h2 className="text-2xl font-bold text-primary-900 mb-4">Managing Cookies</h2>
                <p className="text-primary-600 mb-4">
                  Most web browsers allow you to control cookies through their settings preferences. However, limiting cookies may impact your experience of our website.
                </p>
                
                <div className="bg-primary-50 p-4 rounded-lg mb-4">
                  <h3 className="text-lg font-semibold text-primary-800 mb-2">Browser Settings</h3>
                  <ul className="list-disc pl-6 text-primary-600">
                    <li>Chrome: Settings → Privacy and Security → Cookies</li>
                    <li>Firefox: Options → Privacy & Security → Cookies</li>
                    <li>Safari: Preferences → Privacy → Cookies</li>
                    <li>Edge: Settings → Privacy & Security → Cookies</li>
                  </ul>
                </div>
              </section>

              <section className="mb-8">
                <h2 className="text-2xl font-bold text-primary-900 mb-4">Third-Party Cookies</h2>
                <p className="text-primary-600 mb-4">
                  We may use third-party services that use cookies to:
                </p>
                <ul className="list-disc pl-6 text-primary-600 mb-4">
                  <li>Analyze site traffic and user behavior</li>
                  <li>Provide social media integration</li>
                  <li>Deliver targeted advertising</li>
                  <li>Process secure payments</li>
                </ul>
              </section>

              <section className="mb-8">
                <h2 className="text-2xl font-bold text-primary-900 mb-4">Updates to This Policy</h2>
                <p className="text-primary-600">
                  We may update this Cookie Policy from time to time to reflect changes in our practices or for operational, legal, or regulatory reasons.
                </p>
                <p className="text-primary-500 mt-4 text-sm">
                  Last Updated: February 20, 2024
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-bold text-primary-900 mb-4">Contact Us</h2>
                <p className="text-primary-600 mb-4">
                  If you have questions about our Cookie Policy, please contact us at:
                </p>
                <div className="bg-primary-50 p-4 rounded-lg">
                  <p className="text-primary-700">Email: privacy@dreamintake.app</p>
                  <p className="text-primary-700">Address: 123 Startup Street, Bangalore, India</p>
                </div>
              </section>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}