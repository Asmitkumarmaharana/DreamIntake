import React from 'react';
import Layout from '../components/layout/Layout';
import FounderForm from '../components/signup/FounderForm';

export default function SignupFounder() {
  React.useEffect(() => {
    document.title = 'Founder Signup | Dream Intake';
  }, []);
  
  return (
    <Layout noFooter>
      <div className="min-h-screen bg-primary-50 pt-20 pb-12 flex flex-col items-center justify-center">
        <div className="container mx-auto px-4 max-w-lg">
          <FounderForm />
        </div>
      </div>
    </Layout>
  );
}