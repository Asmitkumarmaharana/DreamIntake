import React from 'react';
import { motion } from 'framer-motion';

interface CardProps {
  children: React.ReactNode;
  className?: string;
  onClick?: () => void;
  floating?: boolean;
  bordered?: boolean;
  padded?: boolean;
}

export default function Card({ 
  children, 
  className = '', 
  onClick, 
  floating = false,
  bordered = false,
  padded = true,
}: CardProps) {
  return (
    <motion.div
      whileHover={floating ? { y: -5, transition: { duration: 0.2 } } : undefined}
      className={`
        bg-white rounded-xl 
        ${floating ? 'shadow-float' : 'shadow-card'} 
        ${bordered ? 'border border-primary-200' : ''} 
        ${padded ? 'p-6' : ''} 
        ${onClick ? 'cursor-pointer' : ''} 
        ${className}
      `}
      onClick={onClick}
    >
      {children}
    </motion.div>
  );
}