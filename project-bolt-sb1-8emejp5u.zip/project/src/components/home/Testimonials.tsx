import React from 'react';
import { motion } from 'framer-motion';
import Card from '../ui/Card';

interface Testimonial {
  content: string;
  author: string;
  role: string;
  company?: string;
  avatarUrl: string;
}

export default function Testimonials() {
  const testimonials: Testimonial[] = [
    {
      content: "Dream Intake helped me secure our seed funding in just 3 weeks. The platform's clean interface and direct investor connections made all the difference.",
      author: "Priya Sharma",
      role: "Founder & CEO",
      company: "MediConnect",
      avatarUrl: "https://randomuser.me/api/portraits/women/44.jpg"
    },
    {
      content: "As an investor, I've discovered innovative startups that I wouldn't have found otherwise. The leaderboard feature helps me identify promising opportunities quickly.",
      author: "Rohit Mehta",
      role: "Angel Investor",
      avatarUrl: "https://randomuser.me/api/portraits/men/32.jpg"
    },
    {
      content: "The boost feature got my startup featured prominently, resulting in 5 investor meetings in a single week. Best ₹300 I've ever spent!",
      author: "Vikram Singh",
      role: "Founder",
      company: "EduReach",
      avatarUrl: "https://randomuser.me/api/portraits/men/67.jpg"
    }
  ];
  
  return (
    <section className="py-20 bg-primary-900">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-3xl sm:text-4xl font-bold text-white mb-4"
          >
            Success Stories
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-xl text-primary-300 max-w-3xl mx-auto"
          >
            See what founders and investors have achieved on our platform
          </motion.p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <Card className="h-full flex flex-col">
                <div className="flex-grow">
                  <svg className="h-10 w-10 text-gold-500 mb-4" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M4.583 17.321C3.553 16.227 3 15 3 13.011c0-3.5 2.457-6.637 6.03-8.188l.893 1.378c-3.335 1.804-3.987 4.145-4.247 5.621.537-.278 1.24-.375 1.929-.311 1.804.167 3.226 1.648 3.226 3.489a3.5 3.5 0 01-3.5 3.5c-1.073 0-2.099-.49-2.748-1.179zm10 0C13.553 16.227 13 15 13 13.011c0-3.5 2.457-6.637 6.03-8.188l.893 1.378c-3.335 1.804-3.987 4.145-4.247 5.621.537-.278 1.24-.375 1.929-.311 1.804.167 3.226 1.648 3.226 3.489a3.5 3.5 0 01-3.5 3.5c-1.073 0-2.099-.49-2.748-1.179z"></path>
                  </svg>
                  <p className="text-primary-700 mb-6">{testimonial.content}</p>
                </div>
                
                <div className="flex items-center">
                  <img 
                    src={testimonial.avatarUrl} 
                    alt={testimonial.author} 
                    className="h-12 w-12 rounded-full object-cover mr-4"
                  />
                  <div>
                    <h4 className="font-semibold text-primary-900">{testimonial.author}</h4>
                    <p className="text-sm text-primary-600">
                      {testimonial.role}
                      {testimonial.company && ` • ${testimonial.company}`}
                    </p>
                  </div>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}