/*
  # Initial Schema Setup

  1. New Tables
    - users
      - id (uuid, primary key)
      - email (text, unique)
      - name (text)
      - user_type (text)
      - created_at (timestamp)
    
    - startups
      - id (uuid, primary key)
      - founder_id (uuid, references users)
      - name (text)
      - short_pitch (text)
      - full_pitch (text)
      - pitch_video_url (text)
      - industries (text[])
      - location (text)
      - views (integer)
      - likes (integer)
      - is_boosted (boolean)
      - boost_expires_at (timestamp)
      - created_at (timestamp)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Users table
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE NOT NULL,
  name text NOT NULL,
  user_type text NOT NULL CHECK (user_type IN ('founder', 'investor')),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE users ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own data"
  ON users
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own data"
  ON users
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id);

-- Startups table
CREATE TABLE IF NOT EXISTS startups (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  founder_id uuid REFERENCES users(id),
  name text NOT NULL,
  short_pitch text NOT NULL,
  full_pitch text,
  pitch_video_url text,
  industries text[] NOT NULL,
  location text NOT NULL,
  views integer DEFAULT 0,
  likes integer DEFAULT 0,
  is_boosted boolean DEFAULT false,
  boost_expires_at timestamptz,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE startups ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view startups"
  ON startups
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Founders can insert own startups"
  ON startups
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = founder_id);

CREATE POLICY "Founders can update own startups"
  ON startups
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = founder_id);