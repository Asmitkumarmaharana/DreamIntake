import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation, Navigate } from 'react-router-dom';
import Home from './pages/Home';
import Discover from './pages/Discover';
import Trending from './pages/Trending';
import Leaderboard from './pages/Leaderboard';
import Login from './pages/Login';
import Signup from './pages/Signup';
import SignupFounder from './pages/SignupFounder';
import SignupInvestor from './pages/SignupInvestor';
import Messages from './pages/Messages';
import FAQ from './pages/FAQ';
import Blog from './pages/Blog';
import PrivacyPolicy from './pages/PrivacyPolicy';
import CookiePolicy from './pages/CookiePolicy';
import Contact from './pages/Contact';
import Terms from './pages/Terms';
import InvestorGuidelines from './pages/InvestorGuidelines';
import FounderResources from './pages/FounderResources';
import Profile from './pages/Profile';
import DreamBot from './components/chatbot/DreamBot';
import NotFound from './pages/NotFound';
import { useAuthStore } from './store/authStore';

function ScrollToTop() {
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);

  return null;
}

// Protected Route Component
function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { isAuthenticated } = useAuthStore();
  
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  return <>{children}</>;
}

function App() {
  return (
    <Router>
      <ScrollToTop />
      <div className="font-sans text-primary-900 bg-white">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/discover" element={<Discover />} />
          <Route path="/trending" element={<Trending />} />
          <Route path="/leaderboard" element={<Leaderboard />} />
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/signup/founder" element={<SignupFounder />} />
          <Route path="/signup/investor" element={<SignupInvestor />} />
          <Route 
            path="/messages" 
            element={
              <ProtectedRoute>
                <Messages />
              </ProtectedRoute>
            } 
          />
          <Route 
            path="/profile" 
            element={
              <ProtectedRoute>
                <Profile />
              </ProtectedRoute>
            } 
          />
          <Route path="/faq" element={<FAQ />} />
          <Route path="/blog" element={<Blog />} />
          <Route path="/privacy-policy" element={<PrivacyPolicy />} />
          <Route path="/cookie-policy" element={<CookiePolicy />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/terms" element={<Terms />} />
          <Route path="/investor-guidelines" element={<InvestorGuidelines />} />
          <Route path="/founder-resources" element={<FounderResources />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
        
        <DreamBot />
      </div>
    </Router>
  );
}

export default App;