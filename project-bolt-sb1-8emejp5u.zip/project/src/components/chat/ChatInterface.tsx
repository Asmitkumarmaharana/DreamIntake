import React, { useState } from 'react';
import { User, Send } from 'lucide-react';
import Button from '../ui/Button';

interface ChatProps {
  recipientName: string;
}

export default function ChatInterface({ recipientName }: ChatProps) {
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState([
    { id: 1, sender: 'recipient', content: 'Hello, I saw your startup and I\'m very interested!', timestamp: new Date().toISOString() },
    { id: 2, sender: 'user', content: 'Thank you! I\'d be happy to discuss more about it.', timestamp: new Date().toISOString() },
  ]);
  
  const handleSendMessage = () => {
    if (message.trim()) {
      setMessages([
        ...messages,
        {
          id: messages.length + 1,
          sender: 'user',
          content: message,
          timestamp: new Date().toISOString()
        }
      ]);
      setMessage('');
      
      // Simulate reply after a short delay
      setTimeout(() => {
        setMessages(prev => [
          ...prev,
          {
            id: prev.length + 1,
            sender: 'recipient',
            content: 'Thanks for the information. When would be a good time to schedule a call?',
            timestamp: new Date().toISOString()
          }
        ]);
      }, 2000);
    }
  };
  
  return (
    <div className="flex flex-col h-[calc(100vh-12rem)] bg-white rounded-lg shadow-md overflow-hidden">
      {/* Chat header */}
      <div className="bg-primary-900 text-white p-4 flex items-center">
        <div className="h-10 w-10 rounded-full bg-primary-700 flex items-center justify-center mr-3">
          <User size={20} />
        </div>
        <div>
          <h3 className="font-medium">{recipientName}</h3>
          <p className="text-xs text-primary-300">Online</p>
        </div>
      </div>
      
      {/* Messages */}
      <div className="flex-grow p-4 overflow-y-auto bg-primary-50">
        <div className="space-y-4">
          {messages.map(msg => (
            <div
              key={msg.id}
              className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`
                  max-w-xs sm:max-w-md rounded-lg p-3
                  ${msg.sender === 'user'
                    ? 'bg-gold-500 text-white rounded-tr-none'
                    : 'bg-white text-primary-800 rounded-tl-none shadow-sm'}
                `}
              >
                <p>{msg.content}</p>
                <p className={`text-xs mt-1 ${msg.sender === 'user' ? 'text-gold-100' : 'text-primary-400'}`}>
                  {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
      
      {/* Message input */}
      <div className="p-4 border-t border-primary-200">
        <div className="flex items-center">
          <input
            type="text"
            value={message}
            onChange={e => setMessage(e.target.value)}
            placeholder="Type your message..."
            className="flex-grow rounded-lg border border-primary-300 px-4 py-2 mr-2 focus:outline-none focus:ring-2 focus:ring-gold-500 focus:border-transparent"
            onKeyDown={e => e.key === 'Enter' && handleSendMessage()}
          />
          <Button onClick={handleSendMessage}>
            <Send size={18} />
          </Button>
        </div>
      </div>
    </div>
  );
}