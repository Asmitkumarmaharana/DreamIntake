import React, { useState } from 'react';
import Layout from '../components/layout/Layout';
import ChatInterface from '../components/chat/ChatInterface';
import { User } from 'lucide-react';

export default function Messages() {
  React.useEffect(() => {
    document.title = 'Messages | Dream Intake';
  }, []);
  
  const [selectedChat, setSelectedChat] = useState<string | null>('Priya Sharma');
  
  const conversations = [
    {
      id: '1',
      name: 'Priya Sharma',
      lastMessage: 'I saw your startup and I\'m very interested!',
      timestamp: '2 hours ago',
      unread: true,
    },
    {
      id: '2',
      name: 'Rohit Mehta',
      lastMessage: 'Can we schedule a call to discuss further?',
      timestamp: 'Yesterday',
      unread: false,
    },
    {
      id: '3',
      name: 'Ananya Desai',
      lastMessage: 'Thanks for sharing your pitch deck.',
      timestamp: '3 days ago',
      unread: false,
    },
  ];
  
  return (
    <Layout>
      <div className="pt-20 pb-20 bg-primary-50 min-h-screen">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-primary-900 mb-2">Messages</h1>
            <p className="text-primary-600">
              Connect with founders and investors through direct messaging
            </p>
          </div>
          
          <div className="flex flex-col md:flex-row gap-6">
            {/* Conversation list */}
            <div className="w-full md:w-80 bg-white rounded-lg shadow-md overflow-hidden">
              <div className="p-4 bg-primary-900 text-white">
                <h2 className="font-medium">Conversations</h2>
              </div>
              
              <div className="divide-y divide-primary-100">
                {conversations.map(conversation => (
                  <button
                    key={conversation.id}
                    className={`
                      w-full text-left px-4 py-3 flex items-center hover:bg-primary-50 transition-colors
                      ${selectedChat === conversation.name ? 'bg-primary-50' : ''}
                    `}
                    onClick={() => setSelectedChat(conversation.name)}
                  >
                    <div className="h-10 w-10 rounded-full bg-primary-200 flex items-center justify-center mr-3">
                      <User size={20} className="text-primary-700" />
                    </div>
                    <div className="flex-grow min-w-0">
                      <div className="flex items-center justify-between">
                        <span className="font-medium text-primary-900">{conversation.name}</span>
                        <span className="text-xs text-primary-500">{conversation.timestamp}</span>
                      </div>
                      <p className="text-sm text-primary-600 truncate">
                        {conversation.lastMessage}
                      </p>
                    </div>
                    {conversation.unread && (
                      <div className="ml-2 h-2 w-2 rounded-full bg-gold-500"></div>
                    )}
                  </button>
                ))}
              </div>
            </div>
            
            {/* Chat interface */}
            <div className="flex-grow">
              {selectedChat ? (
                <ChatInterface recipientName={selectedChat} />
              ) : (
                <div className="h-[calc(100vh-12rem)] bg-white rounded-lg shadow-md flex items-center justify-center">
                  <div className="text-center">
                    <div className="h-16 w-16 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <MessageSquare size={24} className="text-primary-600" />
                    </div>
                    <h3 className="text-xl font-medium text-primary-900 mb-2">No conversation selected</h3>
                    <p className="text-primary-600">
                      Select a conversation from the list to start chatting
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}